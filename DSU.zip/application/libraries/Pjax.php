<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');



class Pjax {

	public function __construct($param)
    {

       $CI =& get_instance();
       
       if(isset($_SERVER["HTTP_X_PJAX"])){

       		
			$CI->load->helper('html_dom');
       	
       		$data = $CI->load->view($param['page'],$param, true);
			$html = str_get_html($data);
			
			echo $html->find('div[id=middle-page]',0)->innertext;	


       }else{

       		$CI->load->view($param['page'],$param);
       }

    }

}
