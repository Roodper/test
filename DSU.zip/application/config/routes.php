<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	http://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There area two reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router what URI segments to use if those provided
| in the URL cannot be matched to a valid route.
|
*/

$route['default_controller'] = "main";
$route['register'] = "main/register";
$route['login'] = "main/login";
$route['logout'] = "main/logout";


$route['admin/table/(:any)/(:num)/make_admin'] = "admin/make_admin/$1/$2";
$route['admin/table/(:any)/(:num)/delete'] = "admin/delete_row/$1/$2";
$route['admin/table/(:any)/(:num)'] = "admin/get_row/$1/$2";
$route['admin/table/(:any)'] = "admin/get_table/$1";
$route['admin'] = "admin";


$route['dashboard/public'] = "dashboard/public_file";
$route['search'] = "dashboard/public_file";
$route['search/(:any)'] = "dashboard/search_file/$1";
$route['dashboard/shared'] = "dashboard/shared";
$route['dashboard/everyone'] = "dashboard/everyone";
$route['dashboard'] = "dashboard";

$route['copy/requested-file-(:num)/(:any)'] = "viewer/copy";
$route['delete/requested-file-(:num)/(:any)'] = "viewer/delete";
$route['download/requested-file-(:num)/(:any)'] = "viewer/download";
$route['view/requested-file-(:num)/(:any)/delete-comment/(:num)'] = "viewer/delete_comment/$3";
$route['view/requested-file-(:num)/(:any)/comment'] = "viewer/post_comment";
$route['view/requested-file-(:num)/(:any)/change'] = "viewer/change_name";
$route['view/requested-file-(:num)/(:any)'] = "viewer/get_file";


$route['share/(public|private|specific|sell)/(:any)'] = "viewer/share";
$route['share/sell-email/(:any)'] 	  = "viewer/share_sell";
$route['share/specific-email/(:any)'] = "viewer/share_specific";

$route['settings'] = "settings";
$route['404_override'] = '';


/* End of file routes.php */
/* Location: ./application/config/routes.php */