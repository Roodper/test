<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Settings extends CI_Controller {

	public function __construct(){

		parent::__construct();

		$this->load->library('form_validation');
		$this->load->helper('date');


		if(!$this->ion_auth->logged_in())
		{
			redirect(base_url());
		}

		


	}


	public function index()
	{
		
		$id = $this->session->userdata('user_id');
		$parser['title']="Settings";
		if($this->session->flashdata('msg-pass'))$parser["msg_pass"] = $this->session->flashdata('msg-pass');

		$parser['user'] = $this->ion_auth->user()->row();
		$parser['user_group'] = $this->ion_auth->get_users_groups($id)->result()[0];


		$time = $parser['user']->created_on;
		$parser['created_on'] = unix_to_human($time);

		$time = $parser['user']->last_login;
		$parser['last_login'] = unix_to_human($time);
		$data= array();


	

		$this->session->set_flashdata('user_row_info', $this->ion_auth->user()->row());

		if($this->input->post('user_submit')){
			$parser['edit_user']=TRUE;

			if($this->session->flashdata('user_row_info')->first_name!=$this->input->post('fname')){
				$this->form_validation->set_rules('fname', 'First Name', 'trim|required|min_length[2]|alpha|xss_clean');
				$data['first_name']= $this->input->post('fname');
			}

			if($this->session->flashdata('user_row_info')->last_name!=$this->input->post('lname')){
				$this->form_validation->set_rules('lname', 'Last Name', 'trim|required|min_length[2]|alpha|xss_clean');
				$data['last_name']= $this->input->post('lname');
			}

			if($this->session->flashdata('user_row_info')->email!=$this->input->post('email')){
				$this->form_validation->set_rules('email', 'Email', 'trim|required|min_length[5]|valid_email|is_unique[users.email]|xss_clean');
				$data['email']= $this->input->post('email');
			}
			if($this->session->flashdata('user_row_info')->paypal!=$this->input->post('paypal')){
				$this->form_validation->set_rules('paypal', 'Paypal Email', 'trim|required|min_length[5]|valid_email|xss_clean');
				$data['paypal']= $this->input->post('paypal');
			}
			if($this->session->flashdata('user_row_info')->company!=$this->input->post('company')){
				$this->form_validation->set_rules('company', 'Company Name', 'trim|required|min_length[3]|alpha_dash|xss_clean');
				$data['company']= $this->input->post('company');
			}

			
			if ($this->form_validation->run() == TRUE)
			{	
				
				if(!empty($data))$this->ion_auth->update($id, $data);
				redirect(base_url().'settings');
			}

		}elseif($this->input->post('password_submit')){
			$parser['change_pass']=TRUE;

			$this->form_validation->set_rules('opass', 'Current Password', 'trim|required|min_length[5]');
			$this->form_validation->set_rules('npass', 'New Password', 'trim|required|min_length[5]|matches[rpass]');
			$this->form_validation->set_rules('rpass', 'New Password Confirmation', 'required');


			$data['password']=$this->input->post('npass');


			if($this->form_validation->run() ==TRUE){
				$identity = $this->session->userdata($this->config->item('identity', 'ion_auth'));

				$change = $this->ion_auth->change_password($identity, $this->input->post('opass'), $this->input->post('npass'));

				if ($change)
				{
					//if the password was successfully changed
					$this->session->set_flashdata('msg-pass', $this->ion_auth->messages());
					redirect(base_url().'settings', 'refresh');
				}
				else
				{
					$this->session->set_flashdata('msg-pass', $this->ion_auth->errors());
					redirect(base_url().'settings', 'refresh');
				}
			}
		}

		$this->load->view('header',$parser);
		$this->load->view('settings',$parser);
		$this->load->view('footer',$parser);

	}



	


}