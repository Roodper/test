<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	public function __construct(){

		parent::__construct();

		$this->load->library('ion_auth');
		
	}

	public function index()
	{
		
		if(!$this->ion_auth->logged_in())
		{
			redirect(base_url());
		}

		$this->load->model('upload_model');
		
		$query = $this->upload_model->select_from_db();

		if($query->num_rows() >0 ){
			$parser['query'] = $query->result_array();	
		}
		


		$parser['title']="Dashboard";
		$parser['js'] = $this->_template_js();

		$this->load->view('header',$parser);
		$this->load->view('dashboard',$parser);
		$this->load->view('footer',$parser);

	}


	public function shared()
	{
		if(!$this->ion_auth->logged_in())
		{
			redirect(base_url());
		}

		$this->load->model('upload_model');
		$query = $this->upload_model->get_share_file();

		if($query->num_rows() >0 ){
			$parser['query'] = $query->result_array();	
		}

		$parser['title']="Shared Files";
		$parser['shared_files']=TRUE;


		$this->load->view('header',$parser);
		$this->load->view('dashboard_shared',$parser);
		$this->load->view('footer',$parser);

	}

	public function public_file()
	{
		if($this->input->post('search')){
			redirect(base_url().'search/'.$this->input->post('search'));
		}

		if(!$this->ion_auth->logged_in())
		{
			redirect(base_url());
		}


		$this->load->model('upload_model');
		$query = $this->upload_model->get_public_file();

		if($query->num_rows() >0 ){
			$parser['query'] = $query->result_array();	
		}

		$parser['title']="Public files";
		$parser['shared_files']=TRUE;


		$this->load->view('header',$parser);
		$this->load->view('dashboard_public',$parser);
		$this->load->view('footer',$parser);

	}

	public function search_file($keyword=NULL)
	{

		// search file here among public file
		$this->load->model('upload_model');
		$query = $this->upload_model->search_from_db(trim($keyword));



		 if($query->num_rows() >0 ){
		 	$parser['query'] = $query->result_array();	
		 }

		$parser['title']="Search";
		$parser['shared_files']=TRUE;


		$this->load->view('header',$parser);
		$this->load->view('dashboard_public',$parser);
		$this->load->view('footer',$parser);

	}


	public function everyone(){
		if(!$this->ion_auth->logged_in())
		{
			redirect(base_url());
		}

		// this is only for admin
		if(!$this->ion_auth->is_admin())
		{
			redirect(base_url());
		}

		$this->load->model('upload_model');
		$query = $this->upload_model->get_everyone_file();

		if($query->num_rows() >0 ){
			$parser['query'] = $query->result_array();	
		}

		$parser['title']="All files in system";
		$parser['shared_files']=TRUE;


		$this->load->view('header',$parser);
		$this->load->view('dashboard_public',$parser);
		$this->load->view('footer',$parser);

		

		
	}

	private function _template_js(){


		return "
<script type=\"text/javascript\" src='".base_url()."assets/js/min_plus.js'></script>
<script type=\"text/javascript\" src='".base_url()."assets/js/plupload.full.js'></script>
<script type=\"text/javascript\">
  $(function() {
      
      var uploader = new plupload.Uploader({
        runtimes : 'html5,flash,gears,silverlight,browserplus,html4',
        browse_button : 'pickFile',
        max_file_size : '5gb',
        container: 'file-uploader',
        chunk_size:'200kb',
        drop_element : 'drag',
        url : '".base_url()."uploader',
        flash_swf_url : '".base_url()."assets/js/plupload.flash.swf',
        silverlight_xap_url : '".base_url()."assets/js/plupload.silverlight.xap',
        
      });
       uploader.bind('Init', function(up, params) {
        if (uploader.features.dragdrop) {

          $('#file-uploader').bind('dragenter', function() {
            $(this).addClass('hover');
          });

          $('.drag').bind('dragleave', function() {
            $('#file-uploader').removeClass('hover');
          });


          var target = $(\"#drag\");
          
          target.ondragover = function(event) {
            event.dataTransfer.dropEffect = \"copy\";
          };
          
          target.ondragenter = function() {
            this.className = \"dragover\";
          };
          
          target.ondragleave = function() {
            this.className = \"\";
          };
          
          target.ondrop = function() {
            this.className = \"\";
          };
        }
      });

      uploader.init(); 

      uploader.bind('FilesAdded', function(up, files) {

        $.each(files, function(i, file) {
          $('#file-uploader').removeClass('hover').addClass('progress');
          $('.param').append('<span class=\"paramName\" data-num=\"'+i+'\" id=\"'+file.id+'\">'+file.name+'<span class=\"paramPercent\"></span></span>');

        });

        up.refresh(); // Reposition Flash/Silverlight
        uploader.start();

      });
      
      
      uploader.bind('UploadProgress', function(up, file) {
        $('#'+file.id+' .paramPercent').html(file.percent + \"%\");
         $('#'+file.id).addClass('show');
        $('.drag').css('width',file.percent + \"%\");

      });

      uploader.bind('FileUploaded', function(up, file,info) {
        

        var len = $('.param').find('.paramName').length;

        if(len == 1 ){
          $('#file-uploader').removeClass();  
        }

        $('#' + file.id).remove();
        
        var obj = $.parseJSON(info.response);
        
        var icon = 'icon_document_alt';
        if(obj.files.type=='Zip')icon='icon_archive_alt';
        else if(obj.files.type=='Image')icon='icon_image';
        else if(obj.files.type=='Video')icon='icon_film';
        else if(obj.files.type=='Audio')icon='icon_volume-high';
        else if(obj.files.type=='PDF')icon='icon_book_alt';
        else if(obj.files.type=='Code')icon='icon_document';


        $('#main_list').append('<a href=\"'+obj.files.url+'\" class=\"row\"><div  aria-hidden=\"true\" class=\"'+icon+' file_icon\"></div><span class=\"name\">'+obj.files.original_name+'</span><span class=\"size\">'+obj.files.size+'</span><span class=\"type\">'+obj.files.type+'</span><span class=\"share\">Private</span></a>');
        
        console.log(obj.files.status);
        
      });
  
  });
</script>";

	}


}