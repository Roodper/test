<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Viewer extends CI_Controller {

	public $creator_id;
	public $folder_id;
	public $file_name;

	public $FolderName;			
	public $path;
	public $webURL;
	public $original_file;
	public $created_file;
	public $created_file_type;
	public $created_file_size;
	public $created_file_ext;



	public function __construct(){

		parent::__construct();

		$this->load->helper('url');

		$this->path= FCPATH.'uploads/';
		$this->webURL=base_url().'uploads/';

		$this->load->model('upload_model');
		$this->load->model('comment_model');

	
		

	}

	public function delete_comment($comment_id = NULL){

		if(!$this->ion_auth->logged_in())
		{
			redirect(base_url());
		}

		$this->creator_id = substr( $this->uri->segment(2),15);
		$this->file_name = $this->uri->segment(3);

		if($this->comment_model->remove_comment($comment_id)){
			$this->session->set_flashdata('msg_view', 'Comment has been deleted');
		}else{
			$this->session->set_flashdata('msg_view', 'Something went wrong');
		}
		
		redirect(base_url().'view/requested-file-'.$this->creator_id.'/'.$this->uri->segment(3));
	}

	public function post_comment(){
		if(!$this->ion_auth->logged_in())
		{
			redirect(base_url());
		}

		$this->creator_id = substr( $this->uri->segment(2),15);
		$this->file_name = $this->uri->segment(3);
		if($this->input->post()){
				$this->load->library('form_validation');
				$this->form_validation->set_rules('comment', 'Your Comment', 'trim|required|min_length[4]|xss_clean');

				if ($this->form_validation->run() == FALSE)
				{
					$this->session->set_flashdata('msg_view', 'Message Should not be empty. And must at least have 4 characters');
					redirect(base_url().'view/requested-file-'.$this->creator_id.'/'.$this->uri->segment(3));
				}
				else
				{
					// everything is correct , so now add the comment to database

					$this->comment_model->add_comment();
					$this->session->set_flashdata('msg_view', 'Your Comment has been posted.');
					redirect(base_url().'view/requested-file-'.$this->creator_id.'/'.$this->uri->segment(3));
				}

		}else{
				$this->session->set_flashdata('msg_view', 'Your Comment was not added. Please Try again');
				redirect(base_url().'view/requested-file-'.$this->creator_id.'/'.$this->uri->segment(3));
		}
	}

	public function copy(){
		
		if(!$this->ion_auth->logged_in())
		{
			redirect(base_url());
		}


		$this->creator_id = substr( $this->uri->segment(2),15);
		$this->folder_id = 'user'.$this->creator_id;
		$this->file_name =  $this->uri->segment(3);

		if($this->creator_id == $this->session->userdata('email')){
			redirect(base_url());
		}

		$query = $this->upload_model->copy_file();

		// do copy file stuff here
		if($query){
			if(! $this->_create_folder()){
			// return false
				die('something went wrong');
			}
			$row = $query->row();
			$new_name = md5(uniqid(rand(), true));
			copy(FCPATH.'uploads'.'/user'.$row->creator_id.'/'.$row->stored_name.'.'.$row->ext , $this->path.$new_name.'.'.$row->ext);

			$this->original_file = $row->name;
			$this->created_file  = $new_name; 
			$this->created_file_type = $row->type; 
			$this->created_file_ext  = $row->ext;
			$this->created_file_size = $row->size;

			$this->upload_model->insert_to_db();
			$parser['msg'] =$this->session->set_flashdata('msg_view','The file has been copied to your drive.');
		}else{
			// something went wrong
			die('wrong');
		}	

		// end of copy file 
		
		redirect(base_url().'dashboard');


	}

	public function get_file(){	// preview file

		if($this->session->flashdata('msg_view')){
			$parser['msg'] =$this->session->flashdata('msg_view');
		}


		$this->creator_id = substr( $this->uri->segment(2),15);
		$this->folder_id = 'user'.$this->creator_id;
		$this->file_name =  $this->uri->segment(3);


		$query = $this->upload_model->get_row_db();

		if ($query->num_rows() >0)
		{

		  
		  $query = $query->row();
		  
		  $filename = $this->path.$this->folder_id.'/'.$this->file_name.'.'.$query->ext;


		  // this is for to be sure that is being share
		  $shared = FALSE;
		  
		  // make the file to be vieable for other user if they have enough privilage
		  if(isset($query->share)){
		  	
		  	$parser['shared_file']=TRUE;

		  	if($this->session->userdata('user_id'))
		  		$parser['copy_file']=base_url().'copy/requested-file-'.$this->creator_id.'/'.$this->file_name;

		  	if($query->share == 2){
		  		//
		  		$query2 = $this->upload_model->check_share_email();
		  		if($query2->num_rows()==0)$shared = TRUE;
			}

			if($query->share == 3){
		  		// this is for sale / so you must be loggin 
		  		if(!$this->session->userdata('email')){
		  			$parser['need_to_login']=TRUE; 
		  			 $shared = TRUE;

		  		}else{
		  			$query2 = $this->upload_model->check_sell_email();
		  			if($query2->num_rows()==0){
		  				$shared = TRUE;
		  				$parser['paypal'] = TRUE;

		  			}

		  			$parser["price"]  = $query->price;

		  			$comment_query = $this->comment_model->get_comments();
					if($comment_query->num_rows()>0){
						$parser['comments'] = $comment_query->result_array();
					}

		  		}
			}


		  }

		  // if admin is viewing
		  if($this->ion_auth->is_admin())
		  {
		  		$shared = FALSE;
		  }


		    if($shared ==FALSE){	  

				if (file_exists($filename)) {
					// file exists

					$comment_query = $this->comment_model->get_comments();
					if($comment_query->num_rows()>0){
						$parser['comments'] = $comment_query->result_array();
					}

					$parser["download_times"] = $this->upload_model->get_download_time()->result_array()[0]['COUNT(id)'];

					$parser["path"]= $filename;

					$parser["preview"]  = $query;
					$parser["stored_name"]  = $this->file_name; 
					$parser["link_preview"] = $this->webURL.$this->folder_id.'/'.$this->file_name;
					$parser["delete_link"] = base_url().'delete/requested-file-'.$this->creator_id.'/'.$this->file_name;
					$parser["down_link"]= base_url().'download/requested-file-'.$this->creator_id.'/'.$this->file_name;
					$parser["comment_link"]= base_url().'view/requested-file-'.$this->creator_id.'/'.$this->file_name.'/comment';

				} else {
					// file does not exist
					$this->upload_model->delete_row_db();
					//redirect(base_url().'dashboard');
				}	
			}

		}

		$parser["title"]="Page View";

		$this->load->view('header',$parser);
		$this->load->view('view',$parser);





	}

	public function change_name(){

		if($this->input->post()){
					

				$this->load->library('form_validation');

				$this->form_validation->set_rules('name', 'File Name', 'trim|required|min_length[1]|alpha_dash|xss_clean');

				if ($this->form_validation->run() == FALSE)
				{
					$this->session->set_flashdata('msg_view', 'There was an error while changing the file name. Please make sure to do not leave it empty.');

					redirect(base_url().$this->uri->segment(1).'/'.$this->uri->segment(2).'/'.$this->uri->segment(3));

				}
				else
				{
					$this->creator_id = substr( $this->uri->segment(2),15);
					$this->folder_id = 'user'.$this->creator_id;
					$this->file_name =  $this->uri->segment(3);

					// correct data 
					if($this->upload_model->update_name($this->input->post('name'))){
						$this->session->set_flashdata('msg_view', 'File Name has been changed.');
					}else{
						$this->session->set_flashdata('msg_view', 'Error Occured while changing name');
					}

					
					redirect(base_url().$this->uri->segment(1).'/'.$this->uri->segment(2).'/'.$this->uri->segment(3));


				}
		}

	}

	public function download(){
		
		$this->creator_id = substr( $this->uri->segment(2),15);
		$this->folder_id = 'user'.$this->creator_id;
		$this->file_name =  $this->uri->segment(3);


		$query = $this->upload_model->get_row_db();

		if ($query->num_rows() >0)
		{

		  $query = $query->row();
		  
		  $filename = $this->path.$this->folder_id.'/'.$this->file_name.'.'.$query->ext;

		  // this is for to be sure that is being share
		  $shared = FALSE;
		  
		  // 
		  if(isset($query->share)){
		  	if($query->share == 2){
		  		 $shared = TRUE;
			}
		  }

		  if($shared ==FALSE){
				if (file_exists($filename)) {
					// file exists

					$data = file_get_contents($filename); // Read the file's contents
					$name = $query->name;

					$file_name = $query->name.'.'.$query->ext;
				    $file_url = $filename;
				    	
				    $query = $this->upload_model->download_file();

				    header('Content-Description: File Downloading ...');
				    header('Pragma: public'); // required
	  				header('Expires: 0'); // no cache
	  				header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
	  				header('Cache-Control: private',false);
				    header('Content-Type: application/octet-stream');
				    header("Content-Transfer-Encoding: Binary"); 
				    header("Content-disposition: attachment; filename=\"".$file_name."\"");
				    header('Content-Length: ' . filesize($file_url));
				    header('Connection: close'); 
	  
				    readfile($file_url);
				  

				} else {
					// file does not exist
					$this->upload_model->delete_row_db();
					//redirect(base_url().'dashboard');
					
				}
			}else{
				redirect(base_url().'dashboard');
			}	

		}else{
			redirect(base_url().'dashboard');
		}

		exit();
		
	}

	public function delete(){


		$this->creator_id = substr( $this->uri->segment(2),15);
		$this->folder_id = 'user'.$this->creator_id;
		$this->file_name =  $this->uri->segment(3);

		if($this->upload_model->delete_row_db()){
			foreach (glob($this->path.$this->folder_id."/".$this->file_name.".*") as $filename) 
			{
				unlink($filename);
			}

		}
		
		redirect(base_url().'dashboard');

	}


	public function share(){

		$share_type = $this->uri->segment(2);
		$this->file_name =  $this->uri->segment(3);

		if($share_type=='public'){
			// wants to be free ( as public file )
			$query = $this->upload_model->update_share_type(1);
			$this->session->set_flashdata('msg_view', 'File mode is set to Public');
		}elseif($share_type=='private'){
			// private
			$query = $this->upload_model->update_share_type(0);
			$this->session->set_flashdata('msg_view', 'File mode is set to Private');
		}elseif($share_type=='sell'){
			// wants to be sold (paypal) )
			if($this->input->post('price')){
				$this->load->library('form_validation');
				$this->form_validation->set_rules('price', 'Item Price', 'trim|required|decimal|greater_than[0]|xss_clean');

				if ($this->form_validation->run() == FALSE)
				{
					$this->session->set_flashdata('msg_view', 'Wrong Price input validation');
					redirect(base_url().'share/sell-email/'.$this->uri->segment(3));
				}
				else
				{
					$query = $this->upload_model->update_price();
					$query = $this->upload_model->update_share_type(3);
					$this->session->set_flashdata('msg_view', 'File mode is set to Sell mode. Now you can sell the key access to this file.');

				}
			}else{
				$this->session->set_flashdata('msg_view', 'You need to Enter a Price !');
				redirect(base_url().'share/sell-email/'.$this->uri->segment(3));	
			}

		}elseif($share_type=='specific'){
			// wants to be shared by emails 

			if($this->input->post()){
				$this->load->library('form_validation');
				$this->form_validation->set_rules('email', 'User Email', 'trim|required|min_length[3]|valid_email|xss_clean');

				if ($this->form_validation->run() == FALSE)
				{
					$this->session->set_flashdata('msg_view', 'Wrong Email input validation');
					redirect(base_url().'share/specific-email/'.$this->uri->segment(3));
				}
				else
				{
					// correct email, so now add it to share_upload db
					if($this->input->post('email') != $this->session->userdata('email')){

						if($this->upload_model->share_email($this->input->post('email'))){
							$query = $this->upload_model->update_share_type(2);
							redirect(base_url().'share/specific-email/'.$this->uri->segment(3));
						}else{
							// duplicate 
							$this->session->set_flashdata('msg_view', 'You\'ve already shared this file with this user email');
							redirect(base_url().'share/specific-email/'.$this->uri->segment(3));
						}

					}else{
						$this->session->set_flashdata('msg_view', 'This is already your file. You can\'t share it with yourself');
						redirect(base_url().'share/specific-email/'.$this->uri->segment(3));
					}
				}
			}else{
				$this->session->set_flashdata('msg_view', 'You need to enter an email !');
				redirect(base_url().'share/specific-email/'.$this->uri->segment(3));
			}

		}
		
		
		if(!isset($query)){
			$this->session->set_flashdata('msg_view','You do not have enough Privilage OR the file has been deleted');
		}

		redirect(base_url().'view/requested-file-'.$this->session->userdata('user_id').'/'.$this->uri->segment(3));
		exit();

	}

	public function share_specific(){

		$this->file_name =  $this->uri->segment(3);
		
		if($this->uri->segment(4)){
			// segment 4 uri is for delete email 
			$query = $this->upload_model->delete_share_email($this->uri->segment(4));
			redirect(base_url().'share/specific-email/'.$this->uri->segment(3));
		}


		if($this->session->flashdata('msg_view')){
			$parser['msg'] =$this->session->flashdata('msg_view');
		}

		$query = $this->upload_model->get_share_email();

		if($query->num_rows()>0){
			$parser['query'] = $query->result_array();	
		}

		$parser["share_options"]=base_url().'share/specific/'.$this->uri->segment(3);
		$parser["return_to_preview"]=base_url().'view/requested-file-'.$this->session->userdata('user_id').'/'.$this->uri->segment(3);
		$parser["title"]="Page View";
		$this->load->view('view',$parser);	
			

	}


	public function share_sell(){

		$this->file_name =  $this->uri->segment(3);
	

		if($this->session->flashdata('msg_view')){
			$parser['msg'] =$this->session->flashdata('msg_view');
		}

		$query = $this->upload_model->get_sell_email();

		if($query->num_rows()>0){
		 	$parser['query'] = $query->result_array();	
		}


		$parser["price"] = $this->upload_model->get_upload_price()->result_array()[0]['price'];
		$parser["share_sell"]=base_url().'share/sell/'.$this->uri->segment(3);
		$parser["return_to_preview"]=base_url().'view/requested-file-'.$this->session->userdata('user_id').'/'.$this->uri->segment(3);
		$parser["title"]="Page View";

		$this->load->view('header',$parser);	
		$this->load->view('view',$parser);	
			

	}


	function _create_folder(){
		// temp upload db for items
		//$this->load->model('ms_temp_upload');

		$rFolder = FALSE; 	// true or false variable ( False = nothing has been set , and True means = to get out of the line)

		if($this->session->userdata('user_id')){

			// this line only should execute if $Folder is TRUE and session dir is available
			if(is_dir($this->path.'user'.$this->session->userdata('user_id'))){
				// reminder to check if is in db too 

				$this->_setting_global_data();

				$rFolder= TRUE;

			}else{
				 $rFolder = FALSE;
			}

		}else{
			die('no user id set');
		}
		
		if($rFolder==FALSE){
		    
			// now here rFolder is the name of the folder
		    $rFolder= 'user'.$this->session->userdata('user_id');
			if(!is_dir($this->path.$rFolder)) //create the folder if it's not already exists
		    {
			     mkdir($this->path.$rFolder,0755,TRUE);
				 
				 $this->_setting_global_data();

			     $rFolder = TRUE;

		    }
			    
		}    

		return TRUE;
	}


	function _setting_global_data(){

		$this->FolderName = 'user'.$this->session->userdata('user_id'); 
		$this->path      .= 'user'.$this->session->userdata('user_id').'/';
		$this->webURL    .= 'requested-file-'.$this->session->userdata('user_id').'/';	

	}






}