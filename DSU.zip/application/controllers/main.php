<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Main extends CI_Controller {

	public function __construct(){

		parent::__construct();

		$this->load->library('ion_auth');

	}
	
	public function index()
	{
		$parser['title']="Welcome to This Document Sharing Utility";


		if ($this->ion_auth->logged_in())
		{
			redirect(base_url().'dashboard');
		}

			$parser['js'] = $this->_js();
			$this->load->view('header',$parser);
			$this->load->view('welcome',$parser);
			$this->load->view('footer',$parser);



	}



	public function register(){
		
		if ($this->ion_auth->logged_in())
		{
			redirect(base_url().'dashboard');
		}

		$parser['page']="register";
		$parser['title']="Register for free ";

		if($this->input->post()){
					

				$this->load->library('form_validation');

				$this->form_validation->set_rules('fname', 'First Name', 'trim|required|min_length[2]|alpha|xss_clean');
				$this->form_validation->set_rules('lname', 'Last Name', 'trim|required|min_length[2]|alpha|xss_clean');
				$this->form_validation->set_rules('email', 'Email', 'trim|required|min_length[5]|valid_email|is_unique[users.email]|xss_clean');
				$this->form_validation->set_rules('pass', 'Password', 'trim|required|min_length[5]|matches[repass]');
				$this->form_validation->set_rules('repass', 'Password Confirmation', 'required');
				$this->form_validation->set_rules('cb', 'Terms and Condition', 'callback_term_check');



				if ($this->form_validation->run() == FALSE)
				{

					$this->load->view('header',$parser);
					$this->load->view('register',$parser);
					$this->load->view('footer',$parser);
				}
				else
				{


					

					$email = strtolower($this->input->post('email'));
					
					$username=explode("@",$email);
					
					$username = $username[0];
					
					$password = $this->input->post('pass');
					
					$additional_data = array(
								'first_name' => strtolower($this->input->post('fname')),
								'last_name' => strtolower($this->input->post('lname')),
								);								

					$register = $this->ion_auth->register($username, $password, $email, $additional_data);

					if($register){

						$this->session->set_flashdata('message', "<p>You have Successfully Registered! Now Please <a href='login'>Login Here</a></p>");
						redirect('register','refresh');

					}else{
						$this->session->set_flashdata('msg_error', '<p>something went wrong while registering your account, Please try again later</p>');
						redirect('register','refresh');
					}
					

				}
			



		}else{
			
			$this->load->view('header',$parser);
			$this->load->view('register',$parser);
			$this->load->view('footer',$parser);
		}
	}

	
	public function login(){

		if ($this->ion_auth->logged_in())
		{
			redirect(base_url().'dashboard');
		}

		$parser['page']="Login";
		$parser['title']="Login to your account";

		if($this->input->post()){
				
			$this->load->library('form_validation');

			
			$this->form_validation->set_rules('email', 'Email', 'trim|required|min_length[5]|valid_email');
			$this->form_validation->set_rules('pass', 'Password', 'trim|required|min_length[5]');
			
			if ($this->form_validation->run() == FALSE)
			{
				$this->load->view('header',$parser);
				$this->load->view('login',$parser);
				$this->load->view('footer',$parser);
			
			}else{


					if ($this->ion_auth->login($this->input->post('email'), $this->input->post('pass')))
					{
						//if the login is successful
						//redirect them back to the home page
						$this->session->set_flashdata('message', $this->ion_auth->messages());
						redirect('dashboard', 'refresh');
					}
					else
					{
						//if the login was un-successful
						//redirect them back to the login page
						$this->session->set_flashdata('msg_error', $this->ion_auth->errors());
						redirect('login', 'refresh'); //use redirects instead of loading views for compatibility with MY_Controller libraries
					}

			}


		}else{
			$this->load->view('header',$parser);
			$this->load->view('login',$parser);
			$this->load->view('footer',$parser);	
		}
	}


	//log the user out
	function logout()
	{
		$this->data['title'] = "Logout";

		//log the user out
		$logout = $this->ion_auth->logout();

		//redirect them to the login page
		$this->session->set_flashdata('message', $this->ion_auth->messages());
		redirect(base_url().'login', 'refresh');
	}





	public function term_check($str)
	{
		if ($str)
		{
			return TRUE;
		}
		else
		{
			$this->form_validation->set_message('term_check', 'You Must agree with our Terms and Condition');
			return FALSE;
		}
	}

	function _js(){
		return "<script>
var WIDTH;
var HEIGHT;
var canvas;
var con;
var g;
var pxs = new Array();
var rint = 50;

$(document).ready(function(){
  WIDTH = window.innerWidth;
  HEIGHT = window.innerHeight;
	$('#container').width(WIDTH).height(HEIGHT);
	canvas = document.getElementById('pixie');
	$(canvas).attr('width', WIDTH).attr('height',HEIGHT);
	con = canvas.getContext('2d');
	for(var i = 0; i < 50; i++) {
		pxs[i] = new Circle();
		pxs[i].reset();
	}
	setInterval(draw,rint);
	setInterval(draw,rint2);

});

function draw() {
	con.clearRect(0,0,WIDTH,HEIGHT);
	for(var i = 0; i < pxs.length; i++) {
		pxs[i].fade();
		pxs[i].move();
		pxs[i].draw();
	}
}

function Circle() {
	this.s = {ttl:8000, xmax:5, ymax:2, rmax:10, rt:1, xdef:960, ydef:540, xdrift:4, ydrift: 4, random:true, blink:true};

	this.reset = function() {
		this.x = (this.s.random ? WIDTH*Math.random() : this.s.xdef);
		this.y = (this.s.random ? HEIGHT*Math.random() : this.s.ydef);
		this.r = ((this.s.rmax-1)*Math.random()) + 1;
		this.dx = (Math.random()*this.s.xmax) * (Math.random() < .5 ? -1 : 1);
		this.dy = (Math.random()*this.s.ymax) * (Math.random() < .5 ? -1 : 1);
		this.hl = (this.s.ttl/rint)*(this.r/this.s.rmax);
		this.rt = Math.random()*this.hl;
		this.s.rt = Math.random()+1;
		this.stop = Math.random()*.2+.4;
		this.s.xdrift *= Math.random() * (Math.random() < .5 ? -1 : 1);
		this.s.ydrift *= Math.random() * (Math.random() < .5 ? -1 : 1);
	}

	this.fade = function() {
		this.rt += this.s.rt;
	}

	this.draw = function() {
		if(this.s.blink && (this.rt <= 0 || this.rt >= this.hl)) this.s.rt = this.s.rt*-1;
		else if(this.rt >= this.hl) this.reset();
		var newo = 1-(this.rt/this.hl);
		con.beginPath();
		con.arc(this.x,this.y,this.r,0,Math.PI*2,true);
		con.closePath();
		var cr = this.r*newo;
		g = con.createRadialGradient(this.x,this.y,0,this.x,this.y,(cr <= 0 ? 1 : cr));
		g.addColorStop(0.0, 'rgba(238,180,28,'+newo+')');
		g.addColorStop(this.stop, 'rgba(238,180,28,'+(newo*.2)+')');
		g.addColorStop(1.0, 'rgba(238,180,28,0)');
		con.fillStyle = g;
		con.fill();
	}

	this.move = function() {
		this.x += (this.rt/this.hl)*this.dx;
		this.y += (this.rt/this.hl)*this.dy;
		if(this.x > WIDTH || this.x < 0) this.dx *= -1;
		if(this.y > HEIGHT || this.y < 0) this.dy *= -1;
	}

	this.getX = function() { return this.x; }
	this.getY = function() { return this.y; }
}
</script>";
	}


}

