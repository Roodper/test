<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin extends CI_Controller {

	public function __construct(){

		parent::__construct();

		$this->load->library('form_validation');
		$this->load->helper('date');

		$this->load->model('admin_model');

		if(!$this->ion_auth->logged_in())
		{
			redirect(base_url());
		}

		if(!$this->ion_auth->is_admin())
		{
			redirect(base_url());
		}
		


	}

	public function get_table($table = NULL){

		if(empty($table))redirect(base_url().'admin');


		$parser['title']="Admin panel";
		$parser['table_name']=$table;
		$parser['t_head'] = $this->admin_model->get_head_table($table)->result_array();
		$parser['t_body'] = $this->admin_model->get_body_table($table)->result_array();

		$this->load->view('header',$parser);
		$this->load->view('admin',$parser);
		$this->load->view('footer',$parser);


	}

	public function make_admin($table = NULL,$id = NULL){
		
		$this->admin_model->make_admin($id);

		$this->session->set_flashdata('msg_admin', 'User Rank Has been updated');
		redirect(base_url().'admin/table/'.$this->uri->segment(3).'/'.$this->uri->segment(4),'refresh');

	}

	public function get_row($table = NULL,$id = NULL){
		if(empty($id))redirect(base_url().'admin');


		if($this->session->flashdata('msg_admin'))$parser['msg_admin'] =$this->session->flashdata('msg_admin');


		if($this->input->post()){

			$data = array();

			foreach ($this->input->post() as $name=>$val ) {
				if($name=='change')break;

				if($name=='user_id' ||$name=='id'){
					$this->form_validation->set_rules($name, 'The '.$name.' Field', 'trim|required|is_natural_no_zero|xss_clean');	

				}elseif($name=='shared_email' ||$name=='paypal_email' ||$name=='email'){
					$this->form_validation->set_rules($name, 'The '.$name.' Field', 'trim|required|min_length[5]|valid_email|xss_clean');	
				}

				$data[$name]=$val;
				
			}
			

				if ($this->form_validation->run() == FALSE)
				{
					$this->session->set_flashdata('msg_admin', 'Something Went Wrong ! It must be from a wrong input field');
				}else{
					// success now change the row in table
					if($this->admin_model->update_row($table,$id,$data)){
						$this->session->set_flashdata('msg_admin', 'The Data has been Updated.');
					}else{
						$this->session->set_flashdata('msg_admin', 'Something Went Wrong !');
					}
				}
				redirect(base_url().'admin/table/'.$this->uri->segment(3).'/'.$this->uri->segment(4),'refresh');


		}

		$query = $this->admin_model->get_row($table,$id);
		
		if($query->num_rows()){
			$parser['item_row'] = $query->result_array()[0];	
			
			// this is only for admin pageecho 

			if($table=='users' &&  $parser['item_row']['id']!= $this->session->userdata('user_id') && $parser['item_row']['company']!='ADMIN' ){
				$parser['make_admin']=TRUE;
			}



		}else{
			$parser['WRONG']= 'WRONG DATA has been selected';
		}
		
		$parser['table_name']=$table;
		$parser['title']="Admin";

		$this->load->view('header',$parser);
		$this->load->view('admin',$parser);
		$this->load->view('footer',$parser);
	}

	public function delete_row($table = NULL,$id = NULL){
		if(empty($id))redirect(base_url().'admin');

		$this->admin_model->delete_row($table,$id);

		$this->session->set_flashdata('msg_admin', 'The Data has been Deleted.');
		redirect(base_url().'admin/table/'.$this->uri->segment(3),'refresh');


	}

	public function index()
	{

 		$CI =& get_instance();
        $CI->load->database();
        $db = $CI->db->database; // give the config name here (hostname).
		

		$query = $this->admin_model->show_tables();
		$parser['buttons'] = array();

		//var_dump($query->result_array());
		foreach ($query->result_array() as $key => $value) {
			foreach ($value as $row ) {
				$parser['buttons'][]  = $row;
			}
		}

		$parser['title']="Admin";

		
		//if($this->session->flashdata('msg-pass'))$parser["msg_pass"] = $this->session->flashdata('msg-pass');

		

		$this->load->view('header',$parser);
		$this->load->view('admin',$parser);
		$this->load->view('footer',$parser);

	}



	


}