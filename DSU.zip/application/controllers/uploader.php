<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Uploader extends CI_Controller {


	public $FolderName;			
	public $path;
	public $webURL;
	public $original_file;
	public $created_file;
	public $created_file_type;
	public $created_file_size;
	public $created_file_ext;


	public function __construct(){

		parent::__construct();

		
		if(!$_POST && !$this->input->is_ajax_request()){
			die();
		}

		$this->load->library('ion_auth');
		if(!$this->ion_auth->logged_in())
		{
			die();
		}


		$this->path= FCPATH.'uploads/';
		$this->webURL=base_url().'view/';



	}



	public function index($slug_url='zip'){
		
		// create the directory folder for user upload // check weather exist or not and save in db
		if(! $this->_create_folder()){
			// return false
			die('something went wrong');
		}	
		
		//start testing

		$config = array(
            'max_tmp_file_age' => 900,
            'max_execution_time' => 180,
            'target_dir' => $this->path);
	    
	    $this->load->library('chunked_uploader', $config, 'uploader');

	    $response=FALSE;

	    try
	    {
	        $this->uploader->upload();
	        if ($this->uploader->is_completed())
	        {
	            //do_something_with_uploaded_file($this->uploader->get_file_path());
	            $response = 'success'.$this->uploader->get_file_path();

	            if($slug_url=='zip'){
	            	
	            	if($this->_upload_file($this->uploader->get_file_name())){
	            		$this->_response_json(array(
	            				'status'=>'success',
	            				'type'=>$this->created_file_type,
	            				'url'=>$this->webURL.$this->created_file,
	            				'size'=>$this->created_file_size,
	            				'rnid'=>rand(10,1000),
	            				'original_name'=>$this->original_file));

	            	}
	            	
	            	exit;

	            }
	        }
	        else
	        {
	            //$response = new Json_rpc_response('continue');
	            $this->_response_json(array(
	            				'status'=>'chuncked',
	            				'type'=>$this->created_file_type,
	            				'rnid'=>rand(10,1000),
	            				'original_name'=>$this->uploader->get_file_name()));
	        }
	    }
	    catch (RuntimeException $ex)
	    {
	        //$response = new Json_rpc_error_response($ex->getMessage());
			$response = $ex->getMessage();
	    }
	    die($response);
	    //$response->send();

		exit;
		// testing end
		
	  	
	}
	

	

	function _response_json($msg){

		header('application/json');
		header('Pragma: no-cache');
		header('Access-Control-Allow-Credentials: false');
		header('Vary: Accept');
		header('Access-Control-Allow-Headers:Content-Type, Content-Range, Content-Disposition');
		header('Access-Control-Allow-Methods: POST');
		header('Cache-Control: no-store, no-cache, must-revalidate');
		header('Content-Disposition: inline; filename="files.json"');
		header('X-Content-Type-Options: nosniff');
		
		die(json_encode(array("files"=>$msg)));

	}



	function _upload_file($uploadedFile){


		$ext =  pathinfo($uploadedFile, PATHINFO_EXTENSION);
		$size = filesize($this->path.$uploadedFile); 

		
		$this->original_file = pathinfo($uploadedFile, PATHINFO_FILENAME);

		$this->created_file_type = $ext;
		$this->created_file_ext  = $ext;

		if($ext=='jpg' OR $ext=='jpeg' OR $ext=='gif' OR $ext=='png'){
			$this->created_file_type = 'Image';
		}
		elseif($ext=='m4v' OR $ext=='mp4' OR $ext=='ogv' OR $ext=='webmv' OR $ext=='ogg' OR $ext=='flv' OR $ext=='avi' OR $ext=='divx' OR $ext=='mov' OR $ext=='mpeg' OR $ext=='mpg'){
			$this->created_file_type = 'Video';
		}
		elseif($ext=='mp3' OR $ext=='m4a' OR $ext=='oga' OR $ext=='webma' OR  $ext=='fla' ){
			$this->created_file_type = 'Audio';
		}
		elseif($ext=='txt' ){
			$this->created_file_type = 'Text';
		}
		elseif($ext=='bsh' OR $ext=='c' OR $ext=='cc' OR $ext=='cpp' OR $ext=='csh' OR $ext=='cs' OR $ext=='php'
			OR $ext=='css' OR $ext=='cyc' OR $ext=='cv' OR $ext=='sh' OR $ext=='mxml' OR $ext=='perl' OR $ext=='vb'
			OR $ext=='htm' OR $ext=='html' OR $ext=='pm' OR $ext=='rb' OR $ext=='js' OR $ext=='xhtml' OR $ext=='sql'
			OR $ext=='pl' OR $ext=='java' OR $ext=='py' OR $ext=='m' OR $ext=='xml' OR $ext=='xsl'){
			$this->created_file_type = 'Code';
		}
		elseif($ext=='pdf'  ){
			$this->created_file_type = 'PDF';
		}
		elseif($ext=='zip' OR $ext=='rar'){
			$this->created_file_type = 'Zip';
		}
		

		$this->created_file_size = $this->_format_bytes($size);

		$new_name = random_string('unique');

		$this->created_file = $new_name;

		rename($this->path.$uploadedFile,$this->path.$new_name.'.'.$ext);

		
		$this->load->model('upload_model');

		$this->upload_model->insert_to_db();

		return TRUE;
	}

	function _format_bytes($bytes) {

		define("KILO", 1024);
		define("MEGA", KILO * 1024);
		define("GIGA", MEGA * 1024);
		define("TERA", GIGA * 1024);

	    if ($bytes < KILO) {
	        return $bytes . ' B';
	    }
	    if ($bytes < MEGA) {
	        return round($bytes / KILO, 2) . ' KB';
	    }
	    if ($bytes < GIGA) {
	        return round($bytes / MEGA, 2) . ' MB';
	    }
	    if ($bytes < TERA) {
	        return round($bytes / GIGA, 2) . ' GB';
	    }
	    return round($bytes / TERA, 2) . ' TB';
	}


	function _create_folder(){
		// temp upload db for items
		//$this->load->model('ms_temp_upload');

		$rFolder = FALSE; 	// true or false variable ( False = nothing has been set , and True means = to get out of the line)

		if($this->session->userdata('user_id')){

			// this line only should execute if $Folder is TRUE and session dir is available
			if(is_dir($this->path.'user'.$this->session->userdata('user_id'))){
				// reminder to check if is in db too 

				$this->_setting_global_data();

				$rFolder= TRUE;

			}else{
				 $rFolder = FALSE;
			}

		}else{
			die('no user id set');
		}
		
		if($rFolder==FALSE){
		    
			// now here rFolder is the name of the folder
		    $rFolder= 'user'.$this->session->userdata('user_id');
			if(!is_dir($this->path.$rFolder)) //create the folder if it's not already exists
		    {
			     mkdir($this->path.$rFolder,0755,TRUE);
				 
				 $this->_setting_global_data();

			     $rFolder = TRUE;

		    }
			    
		}    

		return TRUE;
	}


	function _setting_global_data(){

		$this->FolderName = 'user'.$this->session->userdata('user_id'); 
		$this->path      .= 'user'.$this->session->userdata('user_id').'/';
		$this->webURL    .= 'requested-file-'.$this->session->userdata('user_id').'/';	

	}



}