<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="utf-8">
  <title><?=$title?></title>

    <link rel="stylesheet" href="<?= base_url(); ?>assets/css/base.min.css">
    <link rel="stylesheet" href="<?= base_url(); ?>assets/css/grid.css">
    <link rel="stylesheet" href="<?= base_url(); ?>assets/css/form.min.css">
    <link rel="stylesheet" href="<?= base_url(); ?>assets/css/buttons.min.css">
    <link rel="stylesheet" href="<?= base_url(); ?>assets/css/custom.css">
    <link rel="stylesheet" href="<?= base_url(); ?>assets/css/font.css">
    <link rel="stylesheet" href="<?=base_url()?>assets/css/avgrund.css">
    <?php if(isset($style))echo $style;?>
  
</head>
<body>

<!-- container  -->
<div class="container">
    
    <!-- header container -->
    <header>

        <div class="wrapper">

            <!-- Logo -->
            <div class="logo">
                <a href="<?=base_url()?>"><div aria-hidden="true" class="icon_documents_alt logo_alt"></div> Document Sharing Utility</a><br/>
                <span>Developed by Soheil B.Marvasti</span>
            </div>
            <!-- Navigation -->
            <div class="search">
              <form class="search_form" method="post" action="<?= base_url(); ?>search">
                <input type="text" name="search" id="search" placeholder="Search ...">
                <button id="submit_search" type="submit">search</button>
              </form>
            </div>
            <!-- Navigation -->
         <?php if($this->session->userdata('user_id')){?> 
            <nav>
                 <span><a class="main-hover" href="settings">Menu</a>
                    <div class="hover-menu">
                      <a href="<?= base_url();?>dashboard">Dashboard</a>
                      <a href="<?= base_url();?>settings">Settings</a>
                      <?php if($this->ion_auth->is_admin())
                            {
                              echo   '<a href="'.base_url().'admin">Admin panel</a>';
                            } 
                        ?>
                      <a href="<?= base_url();?>logout">Logout</a>
                    </div>
                </span>
            </nav>
            <?php } ?>
        </div>
    </header>