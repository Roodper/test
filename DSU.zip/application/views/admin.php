

    <!-- middle page -->
    <div id="middle-page" class="wrapper ">
      <div class="pure-g-r full-height">
        <div class="list-file pure-u-1 full-height">
            <div class="inside-pad-3">
              <h3><a href="<?=base_url()?>admin">Admin Panel</a></h3>
              <?php 
              if(isset($msg_admin))echo '<div class="error-setting"><p>'.$msg_admin.'</p></div>';
              if(isset($WRONG))echo '<div class="error-setting"><p>'.$WRONG.'</p></div>';


              if(isset($buttons)){
                echo "<div class='btn-holders'>";
                foreach($buttons as $btn) {
                  echo "<a href='".base_url().'admin/table/'."$btn' class='pure-button pure-button-success'>$btn</a>";
                }
                echo "</div>";
              }elseif(isset($t_head)) {
                echo "<div class=\"table_holder\"> ";
                echo "<table>";
                echo "<caption>".ucfirst($table_name)." Table</caption><thead><tr>";
                  foreach($t_head as $row) {
                    echo "<th>".$row['Field']."</th>";
                  }
                echo "</tr></thead><tbody>";
                  foreach($t_body as $row=>$value) {
                    echo "<tr>";
                      $i=0;
                      $link ;

                      foreach($value as $th) {
                        if($i==0)$link = $th;
                        echo "<td data-attr='".$t_head[$i]['Field']."'><a href='".current_url()."/".$link."'>".$th."</a></td>";
                        $i++;
                      }
                    echo "</tr>";
                  }
                echo "</tbody></table>";
                echo "</div>";
              }elseif (isset($item_row)) {
                
                 echo form_open('','class="pure-form pure-form-aligned"');
                 foreach ($item_row as $label => $value) {
                   
                    if($label=='added_date' || $label=='id' || $label=='modified_date' || $label =='ip_address' || $label=='created_on' || $label=='last_login' || ($label=='company' && $value=='ADMIN')){
                       if($label == 'created_on' || $label == 'last_login')$value = unix_to_human($value);
                       if($label=='ip_address')$value=long2ip($value);

                      echo '<div class="pure-control-group tn"><label>'.$label.'</label> <span>'.$value.'</span></div>';  
                    }elseif($label=='message'){
                      echo '<div class="pure-control-group tn"><label>'.$label.'</label> <textarea name="'.$label.'">'.$value.'</textarea></div>';  
                    }
                    else{
                      echo '<div class="pure-control-group tn"><label>'.$label.'</label> '.form_input($label, $value).'</div>';  
                    }
                    echo "<hr/>";
                 }
                 echo "<button type='submit' class='pure-button' style='float: left;
margin:0px 10px 0 160px;' name='change'>Change</button>";
                 echo form_close();
                
                echo "<a href='".current_url()."/delete' type='submit' class='pure-button pure-button-error' name='delete'>Delete</a>";
                 if(isset($make_admin))echo "<a href='".current_url()."/make_admin' type='submit' class='pure-button pure-button-warning' name='delete'>Make This user Admin</a>";
              }

              ?>

            </div>
        </div>
      </div>
