
    <!-- middle page -->
    <div id="middle-page" class="wrapper medium-width login-panel">

        <div class="top-pad-2">
            <?php 

            $attr = array("class"=>'pure-form pure-form-aligned');
            echo form_open(NULL,$attr);

            echo "<legend>Register</legend>";

            ?>
            <div class="valid-error"> <?=validation_errors(); ?> 

            <?  echo $this->session->flashdata('msg_error');  ?>
            
            </div>

            <div class="valid-success"> <?  echo $this->session->flashdata('message');  ?></div>

            
            <div class="pure-control-group">
                    <?php
                    echo form_label('Full Name', 'fname');

                    $data = array(
                                  'type'        => 'text',
                                  'name'        => 'fname',
                                  'id'          => 'fname',
                                  'value'       =>  set_value('fname'),
                                  'maxlength'   => '10',
                                  'class'       => 'pure-input-1-4',
                                  'placeholder' => 'First'
                                );

                    echo form_input($data);

                      $data = array(
                                  'type'        => 'text',
                                  'name'        => 'lname',
                                  'id'          => 'lname',
                                  'value'       =>  set_value('lname'),
                                  'maxlength'   => '10',
                                  'class'       => 'pure-input-1-4',
                                  'placeholder' => 'Last'
                                );

                    echo form_input($data);

                    ?>
            </div>


            <div class="pure-control-group">
                    <?php
                    echo form_label('Email', 'email');

                    $data = array(
                                  'type'        => 'email',
                                  'name'        => 'email',
                                  'id'          => 'email',
                                  'value'       =>  set_value('email'),
                                  'maxlength'   => '40',
                                  'class'       => 'pure-input-1-2',
                                  'placeholder' => 'Email Address'
                                );

                    echo form_input($data);

                    ?>
            </div>

            <div class="pure-control-group">
                    <?
                    echo form_label('Password', 'pass');

                    $data = array(
                                  'type'        => 'password',
                                  'name'        => 'pass',
                                  'id'          => 'pass',
                                  'value'       => '',
                                  'maxlength'   => '20',
                                  'class'       => 'pure-input-1-2',
                                  'placeholder' => 'Your Password'
                                );

                    echo form_input($data);

                    ?>
            </div>

             <div class="pure-control-group">
                    <?
                    echo form_label('Re-Password', 'repass');

                    $data = array(
                                  'type'        => 'password',
                                  'name'        => 'repass',
                                  'id'          => 'repass',
                                  'value'       => '',
                                  'maxlength'   => '20',
                                  'class'       => 'pure-input-1-2',
                                  'placeholder' => 'Re Enter Your Password'
                                );

                    echo form_input($data);

                    ?>
            </div>
            <span class="dont-have-account">Wait ! I'm already a <a href="<?= base_url()?>login">member</a> !</span>

            <div class="pure-controls">
                        <label for="cb" class="pure-checkbox">
                            <input id="cb" name="cb" value="1" <?php echo set_checkbox('cb', '1'); ?> type="checkbox"> I've read the terms and conditions
                        </label>
                        <br/>
                        <button type="submit" class="pure-button pure-button-primary">Submit</button>
            </div>

            <?

            echo form_close();

            ?>

        </div>
    </div>
    <!-- [end] middle page -->
