    <!-- middle page -->
    <div id="middle-page" class="wrapper ">
      <div class="pure-g-r full-height">
        <div class="list-file pure-u-1 full-height">
            <div class="inside-pad-3 settings">

              <h2>Settings</h2>

              
              <div class="inf">
                <div class="group-field">
                        <label>Used Storage: <?= $user->total_stored?></label>
                </div>
                <div class="group-field">
                        <label>Total Uploaded Files: <?= $user->total_num_stored?></label>
                </div>
                <div class="group-field">
                        <label>Status: <?= $user_group->name ?></label>
                </div>
                <div class="group-field">
                  <label><b>Rank</b>: <?= $user_group->description ?></label>
                </div>
                <div class="group-field">
                  <label>Last Login : <?= $last_login?></label>
                </div>
                <div class="group-field">
                  <label>Account Created on : <?= $created_on?></label>
                </div>
              </div>
              <br/>
            

              <?php if(isset($edit_user))echo "<div class='error-setting'>".validation_errors()."</div>"; ?>
              
              <?php echo form_open('','class="pure-form pure-form-aligned"'); ?>
                  <fieldset>
                    <legend>User settings</legend>
                     <div class="pure-control-group">
                      <label for="username">Username :</label>
                      <input type="text" class="pure-input-1-2" name="username" id="username" value="<?= $user->username?>" placeholder="Username" />
                    </div>
                    <div class="pure-control-group">
                      <label for="fname">Full Name :</label>
                      <input type="text" class="pure-input-1-4" name="fname" id="fname" value="<?= $user->first_name?>" placeholder="First" />
                      <input type="text" class="pure-input-1-4" name="lname" id="lname" value="<?= $user->last_name?>" placeholder="Last"/>
                    </div>
                    <div class="pure-control-group">
                      <label for="email">Email :</label>
                      <input type="text" class="pure-input-1-2" name="email" id="email" value="<?= $user->email?>"  placeholder="Email"/>
                    </div>

                    <div class="pure-control-group">
                      <label for="paypal">Paypal :</label>
                      <input type="text" class="pure-input-1-2" name="paypal" id="paypal" value="<?= $user->paypal?>"  placeholder="paypal address"/>
                    </div>

                    <div class="pure-control-group">
                      <label for="company">Company :</label>
                      <input type="text" class="" name="company" id="company" value="<?= $user->company?>"  placeholder="Company"/>
                    </div>

                    <div class="pure-control-group">
                      <button type="submit" class="pure-button pure-button-success" style="margin-left: 160px;
margin-top: 20px;" name="user_submit" value="1" >Save Changes</button>
                    </div>

                  </fieldset>
                  <?php echo form_close(); ?>
                  <br/>
                  <?php  if(isset($change_pass))echo "<div class='error-setting'>".validation_errors()."</div>";
                        if(isset($msg_pass))echo "<div class='success-setting'>".$msg_pass."</div>";
                   ?>
                  <?php echo form_open('','class="pure-form pure-form-aligned"'); ?>
                  <fieldset>
                    <legend>Change Password</legend>
                    <div class="pure-control-group">
                      <label for="opass">Current Password :</label>
                      <input type="password" class="pure-input-1-4" name="opass" id="opass" placeholder="xxxxxxxx" />
                    </div>
                    <div class="pure-control-group">
                      <label for="npass">New Password :</label>
                      <input type="password" class="pure-input-1-4" name="npass" id="npass"  placeholder="xxxxxxxx" />
                    </div>
                    <div class="pure-control-group">
                      <label for="rpass">Repeat New Password :</label>
                      <input type="password" class="pure-input-1-4" name="rpass"  id="rpass" placeholder="xxxxxxxx" />
                    </div>

                    <div class="pure-control-group">
                      <button type="submit" style="margin-left: 160px;
margin-top: 20px;" class="pure-button pure-button-primary" name="password_submit" value="1">Change Password</button>
                    </div>

                  </fieldset>

                  <?php echo form_close(); ?>
            </div>
        </div>
      </div>

    </div>
    <!-- [end] middle page -->
