
    <!-- middle page -->
    <div id="middle-page" class="wrapper medium-width">

    	<div class="top-pad-5">
        	 <div class="center-text">

             <h2>Welcome to</h2>
                <h1>Document Sharing Utility</h1>
                <h5>A program designed and developed by Soheil B.Marvasti</h5>
                

               <a data-pjax href="register" class="pure-button pure-button-primary pure-button-large">Register</a>
               <a data-pjax href="login" class="pure-button pure-button-success pure-button-large">Login</a>
            </div>
        </div>
    </div>
    <!-- [end] middle page -->

<canvas id="pixie"></canvas>