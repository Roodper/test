
    <!-- middle page -->
    <div id="middle-page" class="wrapper ">
      <div class="pure-g-r full-height">
        <div class="list-file pure-u-3-4 full-height">
          <div class="inside-pad-2">
            <div id="file-uploader">
               <?php echo form_button('uploadFile','Upload Files + ','class="pure-button pure-button-primary pure-button-large" id="pickFile"'); ?>
               <div class="drag" id="drag"></div>
               <span class="param"></span>
            </div>
            <span class="note">* You can drag any type of files into your browser</span>
            <span class="note">* Drag and Drop function only works in Modern Browsers</span>
          </div>
            <hr/>

            <div id="head_list">
              <div class="inside-pad-1">
                <span class="name">Name</span><span class="size">Size</span><span class="type">Type</span><span class="share">Status</span></div>
              </div>
            <div id="main_list">

              <?php 
              if(isset($query)){
                foreach ($query as $row)
                {
                   $icon = 'icon_document_alt';
                   if($row['type'] == 'Image')$icon = 'icon_image';
                   elseif($row['type'] == 'Video')$icon = 'icon_film';
                   elseif($row['type'] == 'Audio')$icon = 'icon_volume-high';
                   elseif($row['type'] == 'PDF')$icon = 'icon_book_alt';
                   elseif($row['type'] == 'Code')$icon = 'icon_document';
                   elseif($row['type'] == 'Zip')$icon = 'icon_archive_alt';

                    echo '
                      <a class="row" href="'.base_url().'view/requested-file-'.$this->session->userdata('user_id').'/'.$row['stored_name'].'" ><div aria-hidden="true" class="'.$icon.' file_icon"></div>
                    ';

                    if($row['share']==0)$share='Private';
                    if($row['share']==1)$share='Public';
                    if($row['share']==2)$share='Shared';
                    if($row['share']==3)$share='For Sell';

                    echo '<span class="name">'.$row['name'].'</span>
                          <span class="size">'.$row['size'].'</span>
                          <span class="type">'.$row['type'].'</span>
                          <span class="share">'.$share.'</span>';
                   ?>
                    </a>
                   <?php
                }
              }else{
                // no item uploaded yet
                 echo '<div class="no-item">Well ! this is embarrassing. There is no Item in here </div>';
              }



              ?>
            </div>

        </div>
        <div class="slidebar pure-u-1-4 full-height">
          <div class="inside-pad-2">
          <legend><div aria-hidden="true" class=" icon_cloud "></div> Your Drive</legend>
            <a href="<?php echo base_url().'dashboard'; ?>">My Dashboard</a>
            <a href="<?php echo base_url().'dashboard/public'; ?>">Public Files</a>
            <a href="<?php echo base_url().'dashboard/shared'; ?>">Shared Files</a>
             <?php if($this->ion_auth->is_admin())
                            { ?>
                              <a href="<?php echo base_url().'dashboard/everyone'; ?>">All users File</a>
                              <?php
                            } 
                        ?>
          </div>
        </div>
      </div>

    </div>
    <!-- [end] middle page -->

</div>
<!-- [end] of container -->


</body>
</html>