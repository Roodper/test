
</div>
<!-- [end] of container -->
<script type="text/javascript" src="<?= base_url();?>assets/js/jquery.min.js"></script>
<script type="text/javascript" src="<?=base_url()?>assets/js/jquery.avgrund.js"></script>
<!--[if IE 7]>
	<script src="<?= base_url();?>assets/js/lte-ie7.js"></script>
<![endif]-->

<?php if(isset($js))echo $js;?>

</body>
</html>