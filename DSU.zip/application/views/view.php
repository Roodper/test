    <!-- middle page -->
    <div id="middle-page" class="wrapper ">
      <?php 
      if(isset($msg))echo "<div class='msg-wall'>".$msg."</div>"; 

      ?>
     


      <div class="pure-g-r">
      <div id="preview" class="list-file prv pure-u-3-4 full-height">
      <?
      if(isset($preview)){

          if(isset($shared_file)){
            if(isset($copy_file)){
              $copy = "<a href='".$copy_file."' class='download'>Copy To Your Drive</a>";
            }else{
              $copy ='';
            }

          

           echo "<div class='head_info'><a href='".base_url().'dashboard'."' class='main'>Main Files</a><a href='".$down_link."' class='download'>Download</a>".$copy."</div>";
          }else{
            echo "<div class='head_info'><a href='".base_url().'dashboard'."' class='main'>Main Files</a><a href='' class='rename'>Rename</a><a href='".$down_link."' class='download'>Download</a><a href='#modal-share' class='share'>Share</a><a href='' class='delete'>Delete</a></div>";
          }

         
          if($preview->type=='Image'){
             
              echo "<a class='link-mage' href=".$link_preview.'.'.$preview->ext."><img src='".$link_preview.'.'.$preview->ext."' class='image_preview'/></a>";

          }elseif($preview->type=='Video' OR $preview->type=='Audio' OR $preview->type=='Code' OR $preview->type=='PDF' OR $preview->type=='Text'){
              define("PREIVEW_DOC",TRUE);
              echo "<div id=\"document-preview\"></div>";  

          }else{
              
              echo "<div style='color: white;
padding: 271px 210px 0;' id=\"document-preview\">There is no Preview for this file type in here.</div>";  
              
          }


      }elseif(isset($share_options)){
        // this is for specific share option page only
        if(isset($query)){
            echo "<div class='share_options' >";
          foreach ($query as $key=>$row) {

            echo "<div class='id_row' > <div class='email_row' >".$row['shared_email']."</div><a href='".current_url().'/'.$row['id']."' class='pure-button pure-button-error'>Remove</a></div>" ;
          }
            echo "</div>";
        }
        ?>
          <form action="<?= $share_options ?>" method="POST">
            <input name="email" type="email" value="" placeholder="Email ..." /><button type="submit" class="pure-button pure-button-primary">Share</button>
          </form>
          <br/>
          <a href="<?= $return_to_preview?>">Back to Preview</a>

        <?php

      }elseif(isset($share_sell)){ 
          // this is only for sale page
          if(isset($query)){
              echo "<div class='share_options' >";
            foreach ($query as $key=>$row) {

              echo "<div class='id_row' > <div class='email_row' >".$row['shared_email']."</div></div>" ;
            }
              echo "</div>";
          }
          ?>

          <form action="<?= $share_sell ?>" method="POST">
            <input name="price" type="number" value="<?php if(isset($price))echo $price;else echo "0.00";?>" placeholder="Price" /><button type="submit" class="pure-button pure-button-primary" name="sell">Sell</button>
          </form>
          <br/>
          <a href="<?= $return_to_preview?>">Back to Preview</a>

          <?php
      }
      else{
        if(isset($need_to_login))echo "<div style='color: white;
padding: 271px 210px 0;' > To view this item you need to login first<div>";
        if(isset($paypal)){

          echo '<div style="color: white;
padding: 271px 210px 0;" >This File is Private. But you can get key access by purchasing the key for $'.$price.'</div>';
          echo '<br/> <a href="'.current_url().'/purchase">Buy Now</a>';


        }else echo "<div style='color: white;
padding: 71px 40px 0;' >The File that You are looking for is either deleted or you do not have privilate to look at it ! </div>";


      }

      ?>
      </div>
      <div class="slidebar-2 pure-u-1-4 full-height">
      <?php if(isset($preview)){ ?>
        <div class="view-info">
          

          <?  
          $d_times ="";
          if(isset($download_times))$d_times= "<span>Download Time : ".$download_times."</span>"; 
            echo "<div class='link_info'><span>Name : ".$preview->name."</span><span>Type : ".$preview->type."</span><span>Size : ".$preview->size."</span><span>Added Date : ".$preview->added_date."</span>".$d_times."</div>";
            
          ?>
        </div>
        <div class="comment">
            <div class="user-comments">
              <?php 
                if(isset($comments)){
                  foreach ($comments as $key) {
                    echo "<div class='row' ><div class='username'>".$key['username']."</div><div class='message'>".$key['message']."</div><span>".$key['added_date']."</span><a href='".current_url()."/delete-comment/".$key['id']."' class='pure-button' >X</a></div>";
                  }
                }
              ?>
            </div>
            <div class="comment-holder">
              <form action="<?=$comment_link?>" method="POST">
                <textarea name='comment' placeholder='Your Comment ...'></textarea>
                <button type="submit" class="pure-button pure-button-primary pure-button-large" >Post</button>
              </form>
            </div>
          </div>
      </div>
      <? } ?>
      </div>
    </div>
    <!-- [end] middle page -->

</div>
<!-- [end] of container -->



<script src="<?=base_url()?>/assets/js/jquery.min.js"></script>
<script type="text/javascript" src="<?=base_url()?>assets/js/jquery.avgrund.js"></script>

<?php if(defined('PREIVEW_DOC')){ ?>
<script type="text/javascript" src="<?=base_url()?>assets/js/libs/yepnope.1.5.3-min.js"></script>
<script type="text/javascript" src="<?=base_url()?>assets/js/libs/pdfjs/pdf.js"></script>
<script type="text/javascript" src="<?=base_url()?>assets/js/libs/google-code-prettify/prettify.js"></script>
<script type="text/javascript" src="<?=base_url()?>assets/js/libs/flowplayer/flowplayer-3.2.6.min.js"></script> 
<script type="text/javascript" src="<?=base_url()?>assets/js/libs/jPlayer/jquery.jplayer.min.js"></script>
<script type="text/javascript" src="<?=base_url()?>assets/js/ttw-document-viewer.js"></script>
<?php } ?>


<script>
  $(function() {

    <?php if(defined('PREIVEW_DOC')){?>
      var documentViewer = $('#document-preview').documentViewer({
        path:'<?=base_url()?>/assets/js/',
        width: 700
      });
      
      documentViewer.load("<?php echo $link_preview.'.'.$preview->ext; ?>");
    <?php } ?>

    $('.share').avgrund({
      height: 200,
      holderClass: 'custom',
      showClose: true,
      showCloseText: 'close',
      onBlurContainer: '.container',
      template: '<p>Share your item with other people.</p>' +
      '<div class="share-div">' +
      '<a href="<?= base_url().'share/private/'.$stored_name; ?>" class="pure-button pure-button-primary ">Private</a>'+
      '<a href="<?= base_url().'share/public/'.$stored_name; ?>" class="pure-button pure-button-secondary">Public ( for everyone )</a>' +
      '<a href="<?= base_url().'share/specific-email/'.$stored_name; ?>" class="pure-button pure-button-success specific-share">Specific People</a>' +
      '<a href="<?= base_url().'share/sell-email/'.$stored_name; ?>" class="pure-button pure-button-error">Sell via Paypal</a>' +
      '</div>'
    });

    $('.rename').avgrund({
      height: 100,
      holderClass: 'custom',
      showClose: true,
      showCloseText: 'close',
      onBlurContainer: '.container',
      template: '<p>Rename your file name :</p>' +
      '<div class="rename-div">' +
      '<form method="post" action="<?php echo current_url();?>/change"><input type="text" name="name" value="<?php echo $preview->name; ?>"/><button type="submit" class="pure-button pure-button-primary">Change</button></form>'+
      '</div>'
    });

     $('.delete').avgrund({
      height: 100,
      holderClass: 'custom',
      showClose: true,
      showCloseText: 'close',
      onBlurContainer: '.container',
      template: '<p>Are you sure you want to delete ?</p>' +
      '<div class="delete-div">' +
      '<a href="<?php echo $delete_link; ?>" class="pure-button pure-button-primary">Yes</a> <a href="#" class="avgrund-close pure-button" >NO</a>'+
      '</div>'

    });

  });
</script>









</body>
</html>