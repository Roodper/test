<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Comment_model extends CI_Model
{
	
	public function get_comments(){

		$sql = "
		SELECT comments.message, comments.id, comments.added_date , comments.user_id, users.username
		FROM comments
		INNER JOIN users
		ON comments.user_id=users.id
		WHERE comments.stored_name = ? ";

		return $this->db->query($sql, array($this->file_name));

	}

	public function add_comment(){


		$sql = "INSERT INTO comments (stored_name,user_id,message) VALUES (?,?,?)";

		$this->db->query($sql, array( $this->file_name , $this->session->userdata('user_id'),$this->input->post('comment')));

	}

	public function remove_comment($comment_id){
		$admin = FALSE;
		if($this->ion_auth->is_admin())
		{
		  		$admin=TRUE; 
		}
		if($this->session->userdata('user_id') == $this->creator_id || $admin==TRUE){
			// owner of the file preview = full privilage to delete all comments
			$sql = "DELETE FROM comments WHERE id = ? AND stored_name = ? ";
			return $this->db->query($sql, array($comment_id,$this->file_name));
		

		}else{
			$sql = "DELETE FROM comments WHERE id = ? AND stored_name = ? AND user_id = ?";
			return $this->db->query($sql, array($comment_id,$this->file_name,$this->session->userdata('user_id')));

		}
		

	}

	


}

