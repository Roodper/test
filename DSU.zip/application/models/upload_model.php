<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Upload_model extends CI_Model
{
	
	public function insert_to_db(){



		$sql = "INSERT INTO uploads (name,stored_name,creator_id,type,ext,size) VALUES (?,?,?,?,?,?)";

		$this->db->query($sql, array( 
			 					$this->original_file,
			 					$this->created_file, 
			 					$this->session->userdata('user_id'), 
			 					$this->created_file_type,
			 					$this->created_file_ext,
			 					$this->created_file_size
			 					)
		);
		

	}


	public function select_from_db(){

		$sql = "SELECT `name`,`stored_name`,`type`,`size`,`added_date`,`share` FROM uploads WHERE creator_id = ?";

		return $this->db->query($sql, array($this->session->userdata('user_id')));

	}

	public function search_from_db($key){

		$key = '%'.$key.'%';
		$sql = "SELECT `name`,`stored_name`,`type`,`creator_id`,`size`,`added_date`,`share` FROM uploads WHERE  ( `name` LIKE ?  OR `type` LIKE ? OR `ext` LIKE ? ) AND ( share = ? ) ";
		return $this->db->query($sql, array($key,$key,$key,1));


	}


	public function copy_file(){
		// copy file to own drive
   		$sql = "SELECT * FROM uploads WHERE creator_id = ? AND stored_name = ? AND share != ?";
   		$share = 0;
		 // if admin is viewing
		 if($this->ion_auth->is_admin())
		 {
		  		$share =5; 
		 }

		$query= $this->db->query($sql, array($this->creator_id,$this->file_name,$share));

		if($query->num_rows() >0){

			if($query->row()->share ==1)return $query;

			$query2 = $this->check_share_email();
			if($query2->num_rows()>0 || $share ==5){

				return $query;


			}else{
				return FALSE;
			}
		}else{
			return FALSE;
		}



	}

	public function get_download_time(){
		$sql = "SELECT COUNT(id) FROM download WHERE stored_name = ?";
		return $this->db->query($sql, array($this->file_name));
	}

	public function get_row_db(){

		if($this->session->userdata('user_id')==$this->creator_id){
			// own file()

			$sql = "SELECT `name`,`type`,`ext`,`size`,`added_date` FROM uploads WHERE stored_name = ? AND creator_id = ?";
			
			return $this->db->query($sql, array($this->file_name,$this->session->userdata('user_id')));

		}elseif($this->ion_auth->is_admin()){
				$sql = "SELECT `name`,`type`,`size`,`ext`,`added_date`,`share` , `price` FROM uploads WHERE stored_name = ? AND creator_id = ? ";
			return  $this->db->query($sql, array($this->file_name,$this->creator_id));
		}
		else{
			// others people file
		
			$sql = "SELECT `name`,`type`,`size`,`ext`,`added_date`,`share` , `price` FROM uploads WHERE stored_name = ? AND creator_id = ? AND share !='0' ";
			return  $this->db->query($sql, array($this->file_name,$this->creator_id));


		}




	}

	public function update_share_type($type){

		$sql = "UPDATE uploads SET share=?, modified_date=?  WHERE stored_name=? AND creator_id=?";
		return $this->db->query($sql, array($type,date('Y-m-d H:i:s'),$this->file_name,$this->session->userdata('user_id')));

	}

	public function update_price(){

		$sql = "UPDATE uploads SET price=?, modified_date=?  WHERE stored_name=? AND creator_id=?";
		return $this->db->query($sql, array($this->input->post('price'),date('Y-m-d H:i:s'),$this->file_name,$this->session->userdata('user_id')));

	}

	public function update_name($name){

		$sql = "UPDATE uploads SET name=?, modified_date=?  WHERE stored_name=? AND creator_id=?";
		return $this->db->query($sql, array($name,date('Y-m-d H:i:s'),$this->file_name,$this->session->userdata('user_id')));

	}


	public function get_public_file(){
		// to get public share files
		$sql = "SELECT `name`,`stored_name`,`type`,`creator_id`,`size`,`added_date`,`share` FROM uploads WHERE share = ?";
		return $this->db->query($sql, array(1));

	}

	public function get_everyone_file(){
		// to get public share files
		$sql = "SELECT `name`,`stored_name`,`type`,`creator_id`,`size`,`added_date`,`share` FROM uploads ";
		return $this->db->query($sql);

	}


	//  add email of users to share listing of a file
	public function share_email($email){

		$sql = "SELECT `id` FROM share_uploads WHERE stored_name = ? AND shared_email = ?  AND owner_id = ?";
		$query= $this->db->query($sql, array($this->file_name,$email,$this->session->userdata('user_id')));


		if($query->num_rows()==0){
			$sql = "INSERT INTO share_uploads (owner_id,stored_name,shared_email) VALUES (?,?,?)";
			return $this->db->query($sql, array($this->session->userdata('user_id'),$this->file_name,$email));
		}else{
			return FALSE;
		}

	}

	// check if a email is accessible to a shared file 
	public function check_share_email(){
		$sql = "SELECT `id` FROM share_uploads WHERE stored_name = ? AND shared_email = ? ";
		return $this->db->query($sql, array($this->file_name,$this->session->userdata('email')));


	}

	// check if a email is accessible to a shared file 
	public function check_sell_email(){
		$sql = "SELECT `id` FROM share_uploads WHERE stored_name = ? AND shared_email = ? AND bought = ?";
		return $this->db->query($sql, array($this->file_name,$this->session->userdata('email'),1));


	}

	public function download_file(){
		$id ='';
		if($this->session->userdata('user_id')){
			$id = $this->session->userdata('user_id');
		}
		$sql = "INSERT INTO download (user_id,ip,stored_name) VALUES (?,?,?)";

		return $this->db->query($sql, array($id,ip2long($this->input->ip_address()),$this->file_name));

	}

	//  get list of shared emails for a file
	public function get_share_email(){

		$sql = "SELECT `id`,`shared_email` FROM share_uploads WHERE stored_name = ? AND owner_id = ? AND bought = ? ";
		return $this->db->query($sql, array($this->file_name,$this->session->userdata('user_id'),0));


	}

	public function get_upload_price(){
			// own file()
			$sql = "SELECT `price` FROM uploads WHERE stored_name = ? AND creator_id = ?";
			return $this->db->query($sql, array($this->file_name,$this->session->userdata('user_id')));

	}


	//  get list of sell emails for a file
	public function get_sell_email(){

		$sql = "SELECT `id`,`shared_email` FROM share_uploads WHERE stored_name = ? AND owner_id = ? AND bought = ?";
		return $this->db->query($sql, array($this->file_name,$this->session->userdata('user_id'),1));


	}


	public function get_share_file(){
		// to get share files

		$sql ="SELECT share_uploads.id,share_uploads.owner_id,share_uploads.stored_name, 
					  uploads.name,uploads.type,uploads.ext,uploads.size,uploads.added_date,uploads.share
						FROM share_uploads
						INNER JOIN uploads
						ON share_uploads.stored_name=uploads.stored_name
						WHERE share_uploads.shared_email = ? AND uploads.share = ?  ";


		return $this->db->query($sql, array($this->session->userdata('email'),2));

	}


	public function delete_share_email($id){

		$sql = "DELETE FROM share_uploads WHERE id = ? AND stored_name = ? AND owner_id = ?";
		return $this->db->query($sql, array($id,$this->file_name,$this->session->userdata('user_id')));
		
	}


	public function delete_row_db(){

		if($this->session->userdata('user_id')==$this->creator_id){
			$sql = "DELETE FROM uploads WHERE stored_name = ? AND creator_id = ?";
			return $this->db->query($sql, array($this->file_name,$this->session->userdata('user_id')));
		}else{
			return FALSE;
		}
	}


}

