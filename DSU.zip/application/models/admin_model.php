<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin_model extends CI_Model
{
	
	public function show_tables(){


		return $this->db->query('SHOW TABLES');



	}

	public function get_head_table($table){

		$sql = 'SHOW COLUMNS FROM '.$table;
		return $this->db->query($sql);
	}

	public function get_body_table($table){

		$sql = 'SELECT * FROM '.$table.' ORDER BY `id` ';
		return $this->db->query($sql);
	}


	public function get_row($table,$id){

		$sql = 'SELECT * FROM '.$table.' WHERE id = ?';
		return $this->db->query($sql,array($id));
	}


	public function delete_row($table,$id){

		$sql = "DELETE FROM ".$table." WHERE id = ? ";

		return $this->db->query($sql, array($id));

	}

	public function make_admin($id){
		$sql = "UPDATE users_groups SET group_id= ? WHERE user_id = ?";
		$this->db->query($sql, array(1,$id));

		$sql = "UPDATE users SET company= ? WHERE id = ?";
		return $this->db->query($sql, array('ADMIN',$id));
	}

	public function update_row($table,$id,$data){
		
		//print_r($data);
		//exit;
		$this->db->where('id', $id);
		return $this->db->update($table, $data); 

	}
	


}

