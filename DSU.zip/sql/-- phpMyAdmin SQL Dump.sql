-- phpMyAdmin SQL Dump
-- version 3.5.7
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 29, 2013 at 11:03 AM
-- Server version: 5.5.29
-- PHP Version: 5.4.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `dsu_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `cloud_sessions`
--

CREATE TABLE `cloud_sessions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `cloud_sessions`
--

INSERT INTO `cloud_sessions` (`id`, `session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES
(1, 'c4e6a3120a6f4aa4e8b2f94ef7494878', '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.95 Safari/537.36', 1377551465, ''),
(2, 'bb2cc6c27d1291a97e3647e0a3210d82', '127.0.0.1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.95 Safari/537.36', 1377592065, ''),
(3, 'b92c25250b90a193193d4aa7a1683310', '127.0.0.1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.95 Safari/537.36', 1377593853, ''),
(4, 'ca4d21af07be2244e318e6a01c9729fd', '127.0.0.1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.95 Safari/537.36', 1377594930, 'a:8:{s:9:"user_data";s:0:"";s:8:"identity";s:21:"soheilbmm@hotmail.com";s:8:"username";s:9:"soheilbmm";s:5:"email";s:21:"soheilbmm@hotmail.com";s:7:"user_id";s:2:"17";s:14:"old_last_login";s:10:"1377593893";s:23:"flash:old:user_row_info";O:8:"stdClass":20:{s:2:"id";s:2:"17";s:10:"ip_address";s:4:"\0\0";s:8:"username";s:9:"soheilbmm";s:8:"password";s:60:"$2a$08$0FlCIEBmjgHqTU0YbuKkOuYqyBijZ5gx4/1Xb7J5550dOzrAF3NUO";s:4:"salt";s:10:"9afbe2a1b4";s:5:"email";s:21:"soheilbmm@hotmail.com";s:15:"activation_code";N;s:23:"forgotten_password_code";N;s:23:"forgotten_password_time";N;s:13:"remember_code";N;s:10:"created_on";s:10:"1377593893";s:10:"last_login";s:10:"1377593905";s:6:"active";s:1:"1";s:10:"first_name";s:6:"soheil";s:9:"last_name";s:2:"bm";s:7:"company";N;s:6:"paypal";N;s:12:"total_stored";s:1:"0";s:16:"total_num_stored";s:1:"0";s:7:"user_id";s:2:"17";}s:23:"flash:new:user_row_info";O:8:"stdClass":20:{s:2:"id";s:2:"17";s:10:"ip_address";s:4:"\0\0";s:8:"username";s:9:"soheilbmm";s:8:"password";s:60:"$2a$08$0FlCIEBmjgHqTU0YbuKkOuYqyBijZ5gx4/1Xb7J5550dOzrAF3NUO";s:4:"salt";s:10:"9afbe2a1b4";s:5:"email";s:21:"soheilbmm@hotmail.com";s:15:"activation_code";N;s:23:"forgotten_password_code";N;s:23:"forgotten_password_time";N;s:13:"remember_code";N;s:10:"created_on";s:10:"1377593893";s:10:"last_login";s:10:"1377593905";s:6:"active";s:1:"1";s:10:"first_name";s:6:"soheil";s:9:"last_name";s:2:"bm";s:7:"company";N;s:6:"paypal";N;s:12:"total_stored";s:1:"0";s:16:"total_num_stored";s:1:"0";s:7:"user_id";s:2:"17";}}'),
(6, '0b5f9ef43357e28c5815b32de748eaad', '127.0.0.1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.95 Safari/537.36', 1377653978, 'a:7:{s:9:"user_data";s:0:"";s:8:"identity";s:13:"and@gmail.com";s:8:"username";s:3:"and";s:5:"email";s:13:"and@gmail.com";s:7:"user_id";s:2:"18";s:14:"old_last_login";s:10:"1377651385";s:17:"flash:old:message";s:29:"<p>Logged In Successfully</p>";}'),
(7, '64d197d53672e3f01fd817ac1c98ed50', '127.0.0.1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.95 Safari/537.36', 1377674961, 'a:1:{s:9:"user_data";s:0:"";}');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `stored_name` varchar(200) NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `message` text NOT NULL,
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `download`
--

CREATE TABLE `download` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `ip` varchar(20) DEFAULT NULL,
  `stored_name` varchar(200) NOT NULL,
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE `groups` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`, `description`) VALUES
(1, 'admin', 'Administrator'),
(2, 'members', 'General User');

-- --------------------------------------------------------

--
-- Table structure for table `login_attempts`
--

CREATE TABLE `login_attempts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varbinary(16) NOT NULL,
  `login` varchar(100) NOT NULL,
  `time` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `request_pay_out`
--

CREATE TABLE `request_pay_out` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `requested_money` varchar(50) NOT NULL,
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `share_uploads`
--

CREATE TABLE `share_uploads` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `owner_id` int(10) unsigned NOT NULL,
  `stored_name` varchar(200) NOT NULL,
  `shared_email` varchar(100) NOT NULL,
  `bought` tinyint(1) NOT NULL DEFAULT '0',
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `stored_name` varchar(200) NOT NULL,
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `paypal_email` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `uploads`
--

CREATE TABLE `uploads` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `stored_name` varchar(200) NOT NULL,
  `creator_id` int(10) unsigned NOT NULL,
  `type` varchar(20) DEFAULT NULL,
  `ext` varchar(10) NOT NULL,
  `size` varchar(10) NOT NULL DEFAULT '0',
  `modified_date` timestamp NULL DEFAULT NULL,
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `share` tinyint(4) NOT NULL DEFAULT '0',
  `price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `deleted` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `uploads`
--

INSERT INTO `uploads` (`id`, `name`, `stored_name`, `creator_id`, `type`, `ext`, `size`, `modified_date`, `added_date`, `share`, `price`, `deleted`) VALUES
(1, 'Screen_Shot_2013_08_27_at_2.35.56_PM', '725529378abe07ca3b9f3ccca33d45c5', 17, 'Image', 'png', '14.93 KB', NULL, '2013-08-27 08:58:33', 0, 0.00, 0),
(2, '968964_470647416359065_1515833313_n', 'da37df8a7765006f2c1333a86c945418', 18, 'Image', 'jpg', '58.9 KB', NULL, '2013-08-28 00:58:20', 0, 0.00, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varbinary(16) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(80) NOT NULL,
  `salt` varchar(40) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `activation_code` varchar(40) DEFAULT NULL,
  `forgotten_password_code` varchar(40) DEFAULT NULL,
  `forgotten_password_time` int(11) unsigned DEFAULT NULL,
  `remember_code` varchar(40) DEFAULT NULL,
  `created_on` int(11) unsigned NOT NULL,
  `last_login` int(11) unsigned DEFAULT NULL,
  `active` tinyint(1) unsigned DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `paypal` varchar(100) DEFAULT NULL,
  `total_stored` varchar(10) DEFAULT '0',
  `total_num_stored` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `paypal` (`paypal`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `paypal`, `total_stored`, `total_num_stored`) VALUES
(1, '\0\0', 'administrator', '$2a$08', '67f8d9ca9b', 'admin@admin.com', '', NULL, NULL, NULL, 1268889823, 1377523225, 1, 'Admin', 'istrator', 'ADMIN', NULL, '0', 0),
(15, '\0\0', 'soheilbm', '$2a$08', '67f8d9ca9b', 'soheilbm@hotmail.com', NULL, NULL, NULL, NULL, 1375743674, 1377537970, 1, 'david Jay', 'henrie', 'ADMIN', 'soheilbm@hotmail.com', '0', 0),
(16, '\0\0', 'anderson7171', '$2a$08', 'b7a8bfa347', 'anderson7171@gmail.com', NULL, NULL, NULL, NULL, 1377383767, 1377443719, 1, 'anderson', 'bm', 'ADMIN', NULL, '0', 0),
(17, '\0\0', 'soheilbmm', '$2a$08$0FlCIEBmjgHqTU0YbuKkOuYqyBijZ5gx4/1Xb7J5550dOzrAF3NUO', '9afbe2a1b4', 'soheilbmm@hotmail.com', NULL, NULL, NULL, NULL, 1377593893, 1377593905, 1, 'soheil', 'bm', NULL, NULL, '0', 0),
(18, '\0\0', 'and', '$2a$08$VElB5DkICbA5mBR7FaHjU.gBiSMYeZaSmcWv9CzYhZf1lX8.ns1v6', '8a87470c6c', 'and@gmail.com', NULL, NULL, NULL, NULL, 1377651375, 1377653988, 1, 'admin', 'admin', NULL, NULL, '0', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users_groups`
--

CREATE TABLE `users_groups` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uc_users_groups` (`user_id`,`group_id`),
  KEY `fk_users_groups_users1_idx` (`user_id`),
  KEY `fk_users_groups_groups1_idx` (`group_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `users_groups`
--

INSERT INTO `users_groups` (`id`, `user_id`, `group_id`) VALUES
(1, 17, 2),
(2, 18, 2);
