(function (a) {
    a.tiny = a.tiny || {};
    a.tiny.scrollbar = {
        options: {
            axis: "y",
            wheel: 40,
            scroll: true,
            size: "auto",
            sizethumb: "auto"
        }
    };
    a.fn.tinyscrollbar = function (c) {
        var c = a.extend({}, a.tiny.scrollbar.options, c);
        this.each(function () {
            if (!a(this).find(".scrollbar").length) {
                a(this).append('<div class="scrollbar"><div class="track"><div class="thumb"><div class="end"></div></div></div></div>')
            }
            a(this).data("tsb", new b(a(this), c))
        });
        return this
    };
    a.fn.tinyscrollbar_update = function (c) {
        return a(this).data("tsb").update(c)
    };
    a.fn.tinyscrollbar_destroy = function () {
        var c = a(this);
        c.removeData("tsb");
        return c.find(".scrollbar").remove()
    };

    function b(p, f) {
        var j = this;
        var s = p;
        var i = {
            obj: a(".viewport", p)
        };
        var g = {
            obj: a(".scroll-content", p)
        };
        var d = {
            obj: a(".scrollbar", p)
        };
        var l = {
            obj: a(".track", d.obj)
        };
        var o = {
            obj: a(".thumb", d.obj)
        };
        var k = f.axis == "x",
            m = k ? "left" : "top",
            u = k ? "Width" : "Height";
        var q, x = {
                start: 0,
                now: 0
            }, n = {};

        function c() {
            j.update();
            r();
            return j
        }
        this.update = function (y) {
            i[f.axis] = i.obj[0]["offset" + u];
            g[f.axis] = g.obj[0]["scroll" + u];
            g.ratio = i[f.axis] / g[f.axis];
            console.log(g.ratio, i[f.axis], g[f.axis]);
            d.obj.toggleClass("disable", g.ratio >= 1);
            l[f.axis] = f.size == "auto" ? i[f.axis] : f.size;
            o[f.axis] = Math.min(l[f.axis], Math.max(0, (f.sizethumb == "auto" ? (l[f.axis] * g.ratio) : f.sizethumb)));
            d.ratio = f.sizethumb == "auto" ? (g[f.axis] / l[f.axis]) : (g[f.axis] - i[f.axis]) / (l[f.axis] - o[f.axis]);
            q = (y == "relative" && g.ratio <= 1) ? Math.min((g[f.axis] - i[f.axis]), Math.max(0, q)) : 0;
            q = (y == "bottom" && g.ratio <= 1) ? (g[f.axis] - i[f.axis]) : isNaN(parseInt(y)) ? q : parseInt(y);
            v()
        };

        function v() {
            o.obj.css(m, q / d.ratio);
            g.obj.css(m, -q);
            n.start = o.obj.offset()[m];
            var y = u.toLowerCase();
            d.obj.css(y, l[f.axis]);
            l.obj.css(y, l[f.axis]);
            o.obj.css(y, o[f.axis])
        }

        function r() {
            o.obj.bind("mousedown", h);
            o.obj[0].ontouchstart = function (y) {
                y.preventDefault();
                o.obj.unbind("mousedown");
                h(y.touches[0]);
                return false
            };
            l.obj.bind("mouseup", t);
            if (f.scroll && this.addEventListener) {
                s[0].addEventListener("DOMMouseScroll", w, false);
                s[0].addEventListener("mousewheel", w, false)
            } else {
                if (f.scroll) {
                    s[0].onmousewheel = w
                }
            }
        }

        function h(z) {
            n.start = k ? z.pageX : z.pageY;
            var y = parseInt(o.obj.css(m));
            x.start = y == "auto" ? 0 : y;
            a(document).bind("mousemove", t);
            document.ontouchmove = function (A) {
                a(document).unbind("mousemove");
                t(A.touches[0])
            };
            a(document).bind("mouseup", e);
            o.obj.bind("mouseup", e);
            o.obj[0].ontouchend = document.ontouchend = function (A) {
                a(document).unbind("mouseup");
                o.obj.unbind("mouseup");
                e(A.touches[0])
            };
            return false
        }

        function w(z) {
            if (!(g.ratio >= 1)) {
                var z = z || window.event;
                var y = z.wheelDelta ? z.wheelDelta / 120 : -z.detail / 3;
                q -= y * f.wheel;
                q = Math.min((g[f.axis] - i[f.axis]), Math.max(0, q));
                o.obj.css(m, q / d.ratio);
                g.obj.css(m, -q);
                z = a.event.fix(z);
                z.preventDefault()
            }
        }

        function e(y) {
            a(document).unbind("mousemove", t);
            a(document).unbind("mouseup", e);
            o.obj.unbind("mouseup", e);
            document.ontouchmove = o.obj[0].ontouchend = document.ontouchend = null;
            return false
        }

        function t(y) {
            if (!(g.ratio >= 1)) {
                x.now = Math.min((l[f.axis] - o[f.axis]), Math.max(0, (x.start + ((k ? y.pageX : y.pageY) - n.start))));
                q = x.now * d.ratio;
                g.obj.css(m, -q);
                o.obj.css(m, x.now)
            }
            return false
        }
        return c()
    }
})(jQuery);
(function (a) {
    a.fn.paddedWidth = function (b) {
        this.each(function () {
            if (b) {
                var d = a(this),
                    c;
                c = parseInt(d.css("padding-left"), 10) + parseInt(d.css("padding-right"), 10);
                d.width(b - c)
            }
        });
        return this
    };
    a.fn.paddedHeight = function (b) {
        this.each(function () {
            if (b) {
                var d = a(this),
                    c;
                c = parseInt(d.css("padding-top"), 10) + parseInt(d.css("padding-bottom"), 10);
                d.height(b - c)
            }
        });
        return this
    };
    a.fn.verticalPadding = function () {
        return parseInt(this.css("padding-top"), 10) + parseInt(this.css("padding-bottom"), 10)
    };
    a.fn.imagesLoaded = function (e) {
        var c = this.filter("img"),
            b = c.length,
            d = "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///ywAAAAAAQABAAACAUwAOw==";
        c.bind("load.imgloaded", function () {
            if (--b <= 0 && this.src !== d) {
                c.unbind("load.imgloaded");
                e.call(c, this)
            }
        }).each(function () {
            if (this.complete || this.complete === undefined) {
                var f = this.src;
                this.src = d;
                this.src = f
            }
        });
        return this
    }
})(jQuery);
(function (c) {
    var b = function (d) {
        var g, f, e;
        f = {
            pdfjs: ["libs/pdfjs/compatibility.js", "libs/pdfjs/pdf.js"],
            prettify: ["libs/google-code-prettify/prettify.js", "libs/google-code-prettify/prettify.css"],
            flowplayer: ["libs/flowplayer/flowplayer-3.2.6.min.js"],
            jplayer: ["libs/jPlayer/jquery.jplayer.min.js"]
        };
        yepnope.errorTimeout = d.errorTimeout || 4000;
        e = {
            pdfjs: function () {
                return typeof PDFJS !== "undefined"
            },
            prettify: function () {
                return typeof prettyPrint !== "undefined"
            },
            flowplayer: function () {
                return typeof flowplayer !== "undefined"
            },
            jplayer: function () {
                return typeof c.jPlayer !== "undefined"
            }
        };

        function h(k) {
            var j = c.extend({}, d, k);
            g = [];
            if (j.path) {
                var i = {};
                c.each(f, function (m, l) {
                    var n = [];
                    c.each(l, function (p, o) {
                        n.push(j.path + o)
                    });
                    i[m] = n
                });
                f = i
            }
            if (e[j.dependency]()) {
                j.callback()
            } else {
                yepnope({
                    load: f[j.dependency],
                    complete: function () {
                        if (e[j.dependency]()) {
                            if (c.isFunction(j.callback)) {
                                j.callback()
                            }
                        } else {
                            j.errorHandler("There was an error loading the dependency (" + f[j.dependency] + ") Please check your options.path value")
                        }
                    }
                })
            }
        }
        return {
            loadDependency: h
        }
    };
    var a = function (p, u) {
        var s, F, k, r = ["bsh", "c", "cc", "cpp", "cs", "csh", "css", "cyc", "cv", "htm", "html", "java", "js", "m", "mxml", "perl", "php", "pl", "pm", "py", "rb", "sh", "xhtml", "xml", "xsl", "sql", "vb"],
            D = ["png", "jpg", "jpeg", "gif"],
            e = ["mp3", "m4a", "oga", "webma", "fla"],
            w = ["m4v", "ogv", "ogg", "webmv", "flv"],
            j = ["mpg", "mp4", "mpeg", "mov", "divx", "avi", "wmv"],
            S = w.concat(j),
            y = w.concat(e),
            M = {
                width: 500,
                height: "auto",
                debug: false,
                autoplay: true,
                autoLoadDependencies: true,
                enableTextAndCode: true,
                jPlayer: {},
                emptyText: '<div class="document-viewer-empty-text">No Document Loaded</div>',
                unsupportedBrowserText: '<div class="document-viewer-empty-text">This document can not be opened in this browser. Please upgrade.</div>',
                errorText: "An error occurred while loading the ",
                serverResponseText: "Unexpected server response of ",
                path: ""
            }, J = {
                scrollable: ".scrollable",
                viewport: ".viewport",
                scrollContent: ".scroll-content",
                wrapper: ".document-viewer-wrapper",
                outer: ".document-viewer-outer",
                anchor: ".document-viewer"
            }, A = {}, l, m, I, G, O = c('<div class="dv-loading"></div>');

        function N() {
            var T = '<div class="document-viewer-wrapper dv-markup clearfix"><div class="document-viewer-outer dv-markup clearfix"><div class="document-viewer dv-markup clearfix"></div></div><div class="dv-sheet sheet1"></div><div class="dv-sheet sheet2"></div></div>';
            p.append(T);
            s = p.find(J.wrapper);
            F = p.find(J.outer);
            k = p.find(J.anchor);
            G = "document-viewer" + new Date().getTime();
            k.attr("id", G);
            A = c.extend(true, {}, M, u);
            k.html(A.emptyText);
            H(A);
            l = new b({
                path: A.path,
                errorHandler: v
            })
        }

        function z(U) {
            var T = false;
            if (U === "pdf") {
                T = "pdf"
            } else {
                if (U === "txt") {
                    T = "txt"
                } else {
                    if (c.inArray(U, r) !== -1) {
                        T = "code"
                    } else {
                        if (c.inArray(U, S) !== -1) {
                            T = "video"
                        } else {
                            if (c.inArray(U, e) !== -1) {
                                T = "audio"
                            } else {
                                if (c.inArray(U, D) !== -1) {
                                    T = "image"
                                }
                            }
                        }
                    }
                }
            }
            return T
        }

        function v(T) {
            if (A.debug && window.console) {
                console.log("DOCUMENT VIEWER: " + T)
            }
        }

        function x(T) {
            var U = /(?:\.([^.]+))?$/;
            return U.exec(T)[1]
        }

        function f(T) {
            if (T === "txt" || T === "code") {
                s.addClass(R("scrollable"));
                F.addClass(R("viewport"));
                k.addClass(R("scrollContent"));
                s.tinyscrollbar()
            } else {
                s.removeClass(R("scrollable"));
                F.removeClass(R("viewport"));
                k.removeClass(R("scrollContent"));
                s.tinyscrollbar_destroy()
            }
        }

        function R(T) {
            if (J[T]) {
                return J[T].substr(1)
            } else {
                return ""
            }
        }

        function E(U, V) {
            var T;
            if (V === "pdf" || V === "txt" || V === "code") {
                T = typeof U.height !== "string" ? U.height : U.width * 1.3
            } else {
                if (V === "video") {
                    T = typeof U.height !== "string" ? U.height : Math.round((U.width / 16) * 9)
                } else {
                    if (V === "image") {
                        T = U.height
                    } else {
                        if (V === "audio") {
                            T = 0
                        } else {
                            T = "auto"
                        }
                    }
                }
            }
            return T
        }

        function H(T) {
            var U = T.type;
            T.width = T.width || M.width;
            T.height = E(T, U);
            s.paddedWidth(T.width + 2).find(".dv-markup").paddedWidth(T.width);
            if (U == "pdf") {
                k.paddedHeight(T.height).parent().paddedHeight(T.height)
            } else {
                if (U === "txt" || U === "code") {
                    k.parent().paddedHeight(T.height)
                } else {
                    k.height("auto").parent().height("auto")
                }
            }
        }

        function t(T, U) {
            if (U && c.isFunction(U)) {
                k.bind(T, U)
            }
        }

        function P(T) {
            k.trigger(T)
        }

        function q(T, U) {
            if (!A.autoLoadDependencies) {
                U()
            } else {
                l.loadDependency({
                    dependency: T,
                    callback: U
                })
            }
        }

        function K(V, aa) {
            var Y;
            Y = c.extend(true, {}, A, aa);
            if (typeof Y.extension === "undefined") {
                Y.extension = x(V)
            }
            if (typeof Y.type === "undefined") {
                Y.type = z(Y.extension)
            }
            m = Y.type;
            I = V;
            s.removeClass("pdf code txt video audio image").addClass(m);
            Y.loadEventId = new Date().getTime() + "-" + Math.floor(Math.random() * (100000 - 1 + 1)) + 1;
            t(Y.loadEventId, Y.callback);
            H(Y);
            k.html("");
            O.css("top", A.height / 2 - 18);
            k.append(O);
            switch (m) {
            case "pdf":
                var U = new B(V, Y);
                break;
            case "code":
            case "txt":
                if (A.enableTextAndCode === true) {
                    var T = new h(V, Y)
                } else {
                    C(1, "Invalid File Type. Please set enableTextAndCode option to true");
                    v("Invalid File Type. Please set enableTextAndCode option to true")
                }
                break;
            case "video":
                var X = new i(V, Y);
                break;
            case "audio":
                var W = new Q(V, Y);
                break;
            case "image":
                var Z = new g(V, Y);
                break;
            default:
                C(1, "Invalid File Type");
                v("Invalid File Type");
                break
            }
            if (m !== "txt" && m !== "code") {
                f(m)
            }
            if (m === "pdf") {
                P(Y.loadEventId)
            }
        }

        function L() {
            k.html(A.emptyText);
            H(A);
            f()
        }

        function n(T) {
            return z(x(T))
        }

        function C(V, T, W) {
            var U = "<br/><span>" + A.serverResponseText + " " + V + " (" + T + ")</span>";
            k.html('<div class="dv-error">' + A.errorText + m + U + "</div>");
            v("Error loading file (" + I + "). Please make sure that the path is correct")
        }

        function o() {
            O.remove()
        }
        var B = function (U, ab) {
            var X, Z = 1,
                T = c('<div class="pdf-menu"><div class="prev-page" >Prev Page</div><div class="next-page">Next Page</div><div class="go-to-page">Go to page <input></div></div>');
            T.on("click", ".prev-page", function () {
                if (Z > 1) {
                    Z -= 1;
                    Y(Z)
                }
            });
            T.on("click", ".next-page", function () {
                if (Z < X.numPages) {
                    Z += 1;
                    Y(Z)
                }
            });
            T.on("keyup", "input", function () {
                var ac = c(this).val();
                if (ac > 0 && ac <= X.numPages) {
                    Y(ac)
                }
            });

            function W() {
                return !!document.createElement("canvas").getContext
            }

            function aa(ac) {
                k.append(T);
                PDFJS.workerSrc = ab.path + "libs/pdfjs/pdf.js";
                PDFJS.getPdf({
                    url: ac,
                    error: function (ad) {
                        C(ad.target.status, ad.target.statusText)
                    }
                }, function (ad) {
                    X = new PDFJS.PDFDoc(ad);
                    Y(Z)
                })
            }

            function Y(ac) {
                k.find("canvas").remove();
                k.append(V(ac))
            }

            function V(af) {
                var ae, ac, ad;
                ae = X.getPage(af);
                ac = document.createElement("canvas");
                ac.id = "page" + af;
                ad = ac.getContext("2d");
                ac.width = k.width();
                ac.height = k.height();
                ae.startRendering(ad, function () {
                    o()
                });
                return ac
            }
            if (W()) {
                q(["pdfjs"], function () {
                    aa(U)
                })
            } else {
                k.html(ab.unsupportedBrowserText);
                return
            }
            return {
                load: aa,
                setPage: Y
            }
        };
        var h = function (T, U) {
            c.ajax({
                url: U.path + "libs/getContents.php",
                type: "POST",
                data: {
                    file: T
                },
                success: function (V) {
                    V = c.parseJSON(V);
                    if (V.status === "success") {
                        var W = c('<pre class="prettyprint linenums">' + V.response + "</pre>").css("opacity", 0);
                        o();
                        k.append(W);
                        W.animate({
                            opacity: 1
                        });
                        f(U.type);
                        q(["prettify"], function () {
                            if (U.type === "code") {
                                prettyPrint()
                            }
                        });
                        P(U.loadEventId)
                    } else {
                        C("404", "Not Found")
                    }
                },
                error: function (V) {
                    C()
                }
            })
        };
        var i = function (U, V) {
            var T;
            if (c.inArray(V.extension, y) !== -1) {
                T = new Q(U, V)
            } else {
                T = new d(U, V)
            }
        };
        var Q = function (U, ab) {
            var Z, X, W, V, T;
            V = {
                jPlayer: "#jquery_jplayer",
                jPlayerContainer: ".jPlayer-container",
                jPlayerInterface: ".jp-interface",
                playlist: ".playlist",
                playing: ".playing",
                progress: ".progress-wrapper",
                volume: ".volume-wrapper"
            };
            X = {
                swfPath: ab.path + "libs/jPlayer",
                supplied: ab.extension,
                solution: "html, flash",
                cssSelectorAncestor: V.jPlayerInterface,
                errorAlerts: ab.debug,
                warningAlerts: ab.debug,
                size: {
                    height: ab.height,
                    width: ab.width,
                    cssClass: "show-video"
                },
                sizeFull: {
                    width: "100%",
                    height: "90%",
                    cssClass: "show-video-full"
                }
            };

            function Y() {
                var ac, ae, ad;
                ac = '<div class="ttw-video-player"><div class="jPlayer-container"></div><div class="clear"></div><div class="player jp-interface"><div class="player-controls"><div class="play jp-play button"></div><div class="pause jp-pause button"></div><div class="progress-wrapper"><div class="progress-bg"><div class="progress jp-seek-bar"><div class="elapsed jp-play-bar"></div></div></div></div><div class="volume-wrapper"><div class="volume jp-volume-bar"><div class="volume-value jp-volume-bar-value"></div></div></div></div><!-- These controls aren\'t used by this plugin, but jPlayer seems to require that they exist --><span class="unused-controls"><span class="previous jp-previous"></span><span class="next jp-next"></span><span class="jp-video-play"></span><span class="jp-stop"></span><span class="jp-mute"></span><span class="jp-unmute"></span><span class="jp-volume-max"></span><span class="jp-current-time"></span><span class="jp-duration"></span><span class="jp-repeat"></span><span class="jp-repeat-off"></span><span class="jp-gui"></span><span class="jp-restore-screen"></span><span class="jp-full-screen"></span><span class="jp-no-solution"></span></span></div><div class="clear"></div></div>';
                ae = c(ac).css({
                    opacity: 0
                }).appendTo(k);
                ad = k.width();
                Z.size.width = ad;
                ae.width(ad).find(V.jPlayerInterface + ", " + V.jPlayerContainer).paddedWidth(ad);
                if (T) {
                    ae.height(parseInt(ab.height, 10)).find(V.jPlayerContainer).height(parseInt(ab.height, 10) - 34)
                } else {
                    ae.find(V.jPlayerContainer).height(0)
                }
                ae.animate({
                    opacity: 1
                })
            }

            function aa() {
                T = c.inArray(ab.type, w) !== -1;
                Z = c.extend(true, {}, X, ab.jPlayer);
                o();
                Y();
                W = k.find(".jPlayer-container");
                W.bind(c.jPlayer.event.ready, function () {
                    var ac = {};
                    ac[ab.extension] = U;
                    W.jPlayer("setMedia", ac);
                    v("jPlayer Ready");
                    if (ab.autoplay) {
                        W.jPlayer("play")
                    }
                });
                W.bind(c.jPlayer.event.loadstart, function () {
                    P(ab.loadEventId)
                });
                W.bind(c.jPlayer.event.error, function (ac) {
                    C("404", "Not Found")
                });
                W.jPlayer(Z)
            }
            q(["jplayer"], function () {
                aa()
            })
        };
        var d = function (T, U) {
            function V() {
                k.height(U.height);
                o();
                flowplayer(G, U.path + "libs/flowplayer/flowplayer-3.2.7.swf", {
                    clip: {
                        autoPlay: U.autoplay,
                        autoBuffering: true,
                        url: T,
                        height: U.height
                    },
                    plugins: {
                        controls: {
                            backgroundColor: "transparent",
                            backgroundGradient: "none",
                            sliderColor: "#FFFFFF",
                            sliderBorder: "1.5px solid rgba(160,160,160,0.7)",
                            volumeSliderColor: "#FFFFFF",
                            volumeBorder: "1.5px solid rgba(160,160,160,0.7)",
                            timeColor: "#ffffff",
                            durationColor: "#535353",
                            tooltipColor: "rgba(255, 255, 255, 0.7)",
                            tooltipTextColor: "#000000"
                        }
                    },
                    onBegin: function () {
                        P(U.loadEventId)
                    },
                    onError: function (X, W) {
                        C(X, W)
                    }
                })
            }
            q(["flowplayer"], function () {
                V()
            })
        };
        var g = function (T, U) {
            var V = c('<img class="dv-image">').css("opacity", 0);
            V.error(function (W) {
                C("404", "Not Found")
            });
            V.attr("src", T);
            V.imagesLoaded(function () {
                o();
                k.append(V);
                V.animate({
                    opacity: 1
                });
                P(U.loadEventId)
            })
        };
        N();
        return {
            load: K,
            close: L,
            getDocumentType: n
        }
    };
    c.fn.documentViewer = function (d) {
        var e = new a(this, d);
        this.data("document-viewer", e);
        return e
    }
})(jQuery);